package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.auth.AuthManager
import com.example.auth.AuthScreen
import com.example.data.firebase.MirzaCloudRepository
import com.example.data.model.ThemeMode
import com.example.data.model.UiState
import com.example.data.plugins.MirzaPluginEngine
import com.example.data.remote.OpenRouterClient
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.PluginsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SkillsWorkflowsScreen
import com.example.ui.theme.MirzaAiTheme
import com.example.ui.viewmodel.MirzaViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

const val ROUTE_AUTH = "auth"
const val ROUTE_WORKSPACE = "workspace"
const val ROUTE_CHAT = "chat"
const val ROUTE_SKILLS = "skills"
const val ROUTE_PLUGINS = "plugins"
const val ROUTE_STUDIO = "studio"

enum class MirzaTab(
    val route: String,
    val titleRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
) {
    CHAT(ROUTE_CHAT, R.string.nav_chat, Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline, "tab_chat"),
    SKILLS(ROUTE_SKILLS, R.string.nav_skills, Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "tab_skills"),
    PLUGINS(ROUTE_PLUGINS, R.string.nav_plugins, Icons.Filled.Extension, Icons.Outlined.Extension, "tab_plugins"),
    STUDIO(ROUTE_STUDIO, R.string.nav_studio, Icons.Filled.Tune, Icons.Outlined.Tune, "tab_studio"),
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppNavigation()
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val rootNavController = rememberNavController()
    val initialDestination = remember {
        if (auth.currentUser == null) ROUTE_AUTH else ROUTE_WORKSPACE
    }

    LaunchedEffect(currentUser?.uid) {
        val targetRoute = if (currentUser == null) ROUTE_AUTH else ROUTE_WORKSPACE
        val currentRoute = rootNavController.currentDestination?.route
        if (currentRoute != targetRoute) {
            rootNavController.navigate(targetRoute) {
                popUpTo(0) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    NavHost(
        navController = rootNavController,
        startDestination = initialDestination,
        modifier = Modifier.fillMaxSize()
    ) {
        composable(ROUTE_AUTH) {
            MirzaAiTheme(themeMode = ThemeMode.SYSTEM) {
                AuthScreen(
                    onAuthSuccess = {
                        if (rootNavController.currentDestination?.route != ROUTE_WORKSPACE) {
                            rootNavController.navigate(ROUTE_WORKSPACE) {
                                popUpTo(ROUTE_AUTH) { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    }
                )
            }
        }

        composable(ROUTE_WORKSPACE) {
            val user = currentUser
            if (user != null) {
                val uid = user.uid
                key(uid) {
                    AuthenticatedMirzaWorkspace(
                        currentUserId = uid,
                        displayName = user.displayName ?: "Mirza User",
                        email = user.email.orEmpty(),
                        onSignedOut = {
                            rootNavController.navigate(ROUTE_AUTH) {
                                popUpTo(ROUTE_WORKSPACE) { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedMirzaWorkspace(
    currentUserId: String,
    displayName: String,
    email: String,
    onSignedOut: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val workspaceNavController = rememberNavController()
    val backStackEntry by workspaceNavController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_CHAT

    val navigateToTab: (String) -> Unit = { route ->
        workspaceNavController.navigate(route) {
            popUpTo(workspaceNavController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val viewModel: MirzaViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                val repo = MirzaCloudRepository(db)
                val localPrefs = app.getSharedPreferences("mirza_local_keys", Context.MODE_PRIVATE)
                MirzaViewModel(
                    cloudRepository = repo,
                    openRouterClient = OpenRouterClient(
                        customKeyProvider = { localPrefs.getString("local_openrouter_api_key", null) }
                    ),
                    pluginEngine = MirzaPluginEngine(repo),
                    currentUserId = currentUserId,
                    initialDisplayName = displayName,
                    localPrefs = localPrefs
                )
            }
        }
    )

    val settingsState by viewModel.settingsState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val themeMode = remember(settingsState) {
        val raw = (settingsState as? UiState.Success)?.data?.themeMode
        ThemeMode.fromRaw(raw)
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissStatusBanner()
        }
    }

    MirzaAiTheme(themeMode = themeMode) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 680.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar {
                            MirzaTab.entries.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = stringResource(tab.titleRes)
                                        )
                                    },
                                    label = { Text(stringResource(tab.titleRes)) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail {
                            MirzaTab.entries.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = stringResource(tab.titleRes)
                                        )
                                    },
                                    label = { Text(stringResource(tab.titleRes)) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = workspaceNavController,
                        startDestination = ROUTE_CHAT,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                    ) {
                        composable(ROUTE_CHAT) {
                            ChatScreen(
                                viewModel = viewModel,
                                onOpenSkillsTab = { navigateToTab(ROUTE_SKILLS) },
                                onOpenPluginsTab = { navigateToTab(ROUTE_PLUGINS) }
                            )
                        }
                        composable(ROUTE_SKILLS) {
                            SkillsWorkflowsScreen(
                                viewModel = viewModel,
                                onRunWorkflowInChat = { skill, input ->
                                    navigateToTab(ROUTE_CHAT)
                                    viewModel.triggerWorkflowRun(skill, input)
                                }
                            )
                        }
                        composable(ROUTE_PLUGINS) {
                            PluginsScreen(viewModel = viewModel)
                        }
                        composable(ROUTE_STUDIO) {
                            SettingsScreen(
                                viewModel = viewModel,
                                userEmail = email,
                                onSignOut = {
                                    AuthManager.signOut(credentialManager, scope) {
                                        onSignedOut()
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
