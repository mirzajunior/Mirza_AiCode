package com.example.data.plugins

import com.example.data.firebase.MirzaCloudRepository
import com.example.data.model.AiSkill
import com.example.data.model.PluginDefinition
import com.example.data.model.PluginExecutionResult
import com.example.data.model.SkillCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class MirzaPluginEngine(
    private val cloudRepository: MirzaCloudRepository,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build(),
) {

    val availablePlugins: List<PluginDefinition> = listOf(
        PluginDefinition(
            id = "data_analyzer",
            name = "Complex Data & CSV Profiler",
            shortDescription = "Computes exact statistics (mean, median, std dev, min/max, quartiles, Pearson correlation, missing values) on CSV/TSV/JSON datasets.",
            category = "Data Intelligence",
            sampleInputLabel = "CSV / JSON Dataset",
            sampleInputDefault = "month,revenue,cost,users\nJan,12000,7200,410\nFeb,14500,7900,490\nMar,18200,8800,610\nApr,17400,8500,595\nMay,22100,9600,740",
            parametersHint = "{\"raw_data\": \"...csv or json...\", \"focus_column\": \"optional\"}"
        ),
        PluginDefinition(
            id = "calculator",
            name = "Precision Math & Formula Engine",
            shortDescription = "Deterministic evaluator for complex arithmetic, powers, trig, logarithms, and financial growth equations.",
            category = "Computation",
            sampleInputLabel = "Math Expression",
            sampleInputDefault = "(22100 - 12000) / 12000 * 100 + sqrt(144)",
            parametersHint = "{\"expression\": \"(22100 - 12000) / 12000 * 100\"}"
        ),
        PluginDefinition(
            id = "web_fetcher",
            name = "Live Web & API Fetcher",
            shortDescription = "Fetches live public HTTPS web pages or JSON APIs and extracts clean readable text for real-time synthesis.",
            category = "Live Research",
            sampleInputLabel = "HTTPS URL",
            sampleInputDefault = "https://openrouter.ai/api/v1/models",
            parametersHint = "{\"url\": \"https://...\"}"
        ),
        PluginDefinition(
            id = "code_regex_tool",
            name = "Code, JSON & Regex Workbench",
            shortDescription = "Validates and pretty-prints JSON, executes regex pattern matching with capture groups, and inspects code metrics.",
            category = "Engineering",
            sampleInputLabel = "JSON or Regex Test (pattern|||text)",
            sampleInputDefault = """{"status":"ok","items":[1,2,3],"meta":{"env":"cloud"}}""",
            parametersHint = "{\"mode\": \"json_validate|regex|metrics\", \"input\": \"...\", \"pattern\": \"optional\"}"
        ),
        PluginDefinition(
            id = "workspace_memory",
            name = "Cloud Workspace Memory",
            shortDescription = "Reads or saves persistent insights, KPIs, and user context into Firebase Cloud Firestore across all devices.",
            category = "Cloud Sync",
            sampleInputLabel = "Memory Note (title|||content)",
            sampleInputDefault = "Q2 Target|||Maintain gross margin above 45% across all regions.",
            parametersHint = "{\"action\": \"list|save\", \"title\": \"...\", \"content\": \"...\", \"tag\": \"...\"}"
        ),
        PluginDefinition(
            id = "datetime_planner",
            name = "DateTime & Timezone Planner",
            shortDescription = "Provides exact current time across global timezones, ISO-8601 conversions, and date difference calculations.",
            category = "Productivity",
            sampleInputLabel = "Timezone or Date Range (Asia/Jakarta or 2026-01-01..2026-12-31)",
            sampleInputDefault = "Asia/Jakarta",
            parametersHint = "{\"timezone\": \"Asia/Jakarta\", \"from_date\": \"YYYY-MM-DD\", \"to_date\": \"YYYY-MM-DD\"}"
        ),
    )

    fun buildToolsJson(enabledPluginIds: List<String>): JSONArray {
        val arr = JSONArray()
        if ("data_analyzer" in enabledPluginIds) {
            arr.put(
                toolSpec(
                    name = "data_analyzer",
                    description = "Analyze CSV, TSV, or JSON tabular data to compute exact statistical metrics (count, missing, min, max, mean, median, stdDev, Pearson correlations).",
                    properties = JSONObject().apply {
                        put("raw_data", prop("string", "Raw CSV, TSV, or JSON array text to analyze."))
                        put("focus_column", prop("string", "Optional column name to highlight."))
                    },
                    required = listOf("raw_data")
                )
            )
        }
        if ("calculator" in enabledPluginIds) {
            arr.put(
                toolSpec(
                    name = "calculator",
                    description = "Evaluate a mathematical expression accurately (supports +, -, *, /, ^, %, sqrt, sin, cos, tan, log, ln, abs, round).",
                    properties = JSONObject().apply {
                        put("expression", prop("string", "Mathematical expression to evaluate."))
                    },
                    required = listOf("expression")
                )
            )
        }
        if ("web_fetcher" in enabledPluginIds) {
            arr.put(
                toolSpec(
                    name = "web_fetcher",
                    description = "Fetch a live public HTTPS webpage or JSON API and return extracted clean text.",
                    properties = JSONObject().apply {
                        put("url", prop("string", "Public https:// URL to fetch."))
                    },
                    required = listOf("url")
                )
            )
        }
        if ("code_regex_tool" in enabledPluginIds) {
            arr.put(
                toolSpec(
                    name = "code_regex_tool",
                    description = "Validate/format JSON, test regular expressions, or compute code/text complexity metrics.",
                    properties = JSONObject().apply {
                        put("mode", prop("string", "One of: json_validate, regex, metrics"))
                        put("input", prop("string", "Target JSON, code, or text."))
                        put("pattern", prop("string", "Regex pattern when mode=regex."))
                    },
                    required = listOf("mode", "input")
                )
            )
        }
        if ("workspace_memory" in enabledPluginIds) {
            arr.put(
                toolSpec(
                    name = "workspace_memory",
                    description = "Read or save persistent cloud workspace memories synced across the user's devices.",
                    properties = JSONObject().apply {
                        put("action", prop("string", "Either 'list' or 'save'."))
                        put("title", prop("string", "Short title when action='save'."))
                        put("content", prop("string", "Memory content when action='save'."))
                        put("tag", prop("string", "Optional tag like 'data', 'preference', or 'project'."))
                    },
                    required = listOf("action")
                )
            )
        }
        if ("datetime_planner" in enabledPluginIds) {
            arr.put(
                toolSpec(
                    name = "datetime_planner",
                    description = "Get accurate current timestamp in a timezone or compute exact days between two YYYY-MM-DD dates.",
                    properties = JSONObject().apply {
                        put("timezone", prop("string", "IANA timezone like Asia/Jakarta or UTC."))
                        put("from_date", prop("string", "Optional start date YYYY-MM-DD."))
                        put("to_date", prop("string", "Optional end date YYYY-MM-DD."))
                    },
                    required = emptyList()
                )
            )
        }
        return arr
    }

    private fun toolSpec(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String>,
    ): JSONObject = JSONObject().apply {
        put("type", "function")
        put("function", JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", JSONObject().apply {
                put("type", "object")
                put("properties", properties)
                put("required", JSONArray(required))
            })
        })
    }

    private fun prop(type: String, description: String): JSONObject = JSONObject().apply {
        put("type", type)
        put("description", description)
    }

    suspend fun executePlugin(
        pluginId: String,
        argumentsJson: String,
        userId: String,
    ): PluginExecutionResult {
        val args = try {
            JSONObject(argumentsJson)
        } catch (_: Exception) {
            JSONObject()
        }

        return when (pluginId) {
            "data_analyzer" -> {
                val raw = args.optString("raw_data", "")
                val focus = args.optString("focus_column", "")
                runDataAnalyzer(raw, focus)
            }
            "calculator" -> runCalculator(args.optString("expression", ""))
            "web_fetcher" -> runWebFetcher(args.optString("url", ""))
            "code_regex_tool" -> runCodeRegexTool(
                mode = args.optString("mode", "json_validate"),
                input = args.optString("input", ""),
                pattern = args.optString("pattern", "")
            )
            "workspace_memory" -> runWorkspaceMemory(
                userId = userId,
                action = args.optString("action", "list"),
                title = args.optString("title", ""),
                content = args.optString("content", ""),
                tag = args.optString("tag", "general")
            )
            "datetime_planner" -> runDateTimePlanner(
                timezone = args.optString("timezone", "Asia/Jakarta"),
                fromDate = args.optString("from_date", ""),
                toDate = args.optString("to_date", "")
            )
            else -> PluginExecutionResult(
                pluginId = pluginId,
                pluginName = pluginId,
                success = false,
                summary = "Unknown plugin",
                output = "Plugin '$pluginId' is not registered."
            )
        }
    }

    suspend fun runSandboxInput(pluginId: String, userInput: String, userId: String): PluginExecutionResult {
        val trimmed = userInput.trim()
        val argsJson = when (pluginId) {
            "data_analyzer" -> JSONObject().put("raw_data", trimmed).toString()
            "calculator" -> JSONObject().put("expression", trimmed).toString()
            "web_fetcher" -> JSONObject().put("url", trimmed).toString()
            "code_regex_tool" -> {
                if (trimmed.contains("|||")) {
                    val parts = trimmed.split("|||", limit = 2)
                    JSONObject().put("mode", "regex").put("pattern", parts[0]).put("input", parts[1]).toString()
                } else if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                    JSONObject().put("mode", "json_validate").put("input", trimmed).toString()
                } else {
                    JSONObject().put("mode", "metrics").put("input", trimmed).toString()
                }
            }
            "workspace_memory" -> {
                if (trimmed.contains("|||")) {
                    val parts = trimmed.split("|||", limit = 2)
                    JSONObject().put("action", "save").put("title", parts[0]).put("content", parts[1]).toString()
                } else {
                    JSONObject().put("action", "list").toString()
                }
            }
            "datetime_planner" -> {
                if (trimmed.contains("..")) {
                    val parts = trimmed.split("..", limit = 2)
                    JSONObject().put("from_date", parts[0].trim()).put("to_date", parts[1].trim()).toString()
                } else {
                    JSONObject().put("timezone", trimmed.ifBlank { "Asia/Jakarta" }).toString()
                }
            }
            else -> "{}"
        }
        return executePlugin(pluginId, argsJson, userId)
    }

    fun runDataAnalyzer(rawData: String, focusColumn: String = ""): PluginExecutionResult {
        val trimmed = rawData.trim()
        if (trimmed.isBlank()) {
            return PluginExecutionResult("data_analyzer", "Complex Data & CSV Profiler", false, "Empty data", "No dataset provided.")
        }

        return try {
            val table: Pair<List<String>, List<List<String>>> = if (trimmed.startsWith("[")) {
                parseJsonArrayTable(trimmed)
            } else {
                parseDelimitedTable(trimmed)
            }
            val headers = table.first
            val rows = table.second
            if (headers.isEmpty() || rows.isEmpty()) {
                return PluginExecutionResult("data_analyzer", "Complex Data & CSV Profiler", false, "Unrecognized format", "Could not parse columns and rows.")
            }

            val sb = StringBuilder()
            sb.appendLine("Dataset Profile: ${rows.size} rows x ${headers.size} columns")
            sb.appendLine("Columns: ${headers.joinToString(", ")}")
            sb.appendLine()

            val numericSeries = linkedMapOf<String, List<Double>>()

            headers.forEachIndexed { colIdx, colName ->
                if (focusColumn.isNotBlank() && !colName.equals(focusColumn, ignoreCase = true) && headers.size > 8) {
                    return@forEachIndexed
                }
                val values = rows.map { it.getOrElse(colIdx) { "" }.trim() }
                val missing = values.count { it.isBlank() || it.equals("null", true) || it.equals("na", true) }
                val nums = values.mapNotNull { it.replace(",", "").toDoubleOrNull() }

                if (nums.size >= (values.size - missing).coerceAtLeast(1) * 0.7 && nums.isNotEmpty()) {
                    val sorted = nums.sorted()
                    val sum = nums.sum()
                    val mean = sum / nums.size
                    val median = if (sorted.size % 2 == 0) {
                        (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
                    } else {
                        sorted[sorted.size / 2]
                    }
                    val variance = nums.sumOf { (it - mean) * (it - mean) } / nums.size.coerceAtLeast(1)
                    val stdDev = sqrt(variance)
                    val q1 = sorted[(sorted.size * 0.25).toInt().coerceIn(0, sorted.lastIndex)]
                    val q3 = sorted[(sorted.size * 0.75).toInt().coerceIn(0, sorted.lastIndex)]
                    numericSeries[colName] = nums
                    sb.appendLine("• $colName [NUMERIC]: valid=${nums.size}, missing=$missing, sum=${fmt(sum)}, min=${fmt(sorted.first())}, max=${fmt(sorted.last())}, mean=${fmt(mean)}, median=${fmt(median)}, stdDev=${fmt(stdDev)}, Q1=${fmt(q1)}, Q3=${fmt(q3)}")
                } else {
                    val freq = values.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
                        .entries.sortedByDescending { it.value }.take(4)
                        .joinToString { "${it.key}(${it.value})" }
                    val uniqueCount = values.filter { it.isNotBlank() }.toSet().size
                    sb.appendLine("• $colName [CATEGORICAL]: unique=$uniqueCount, missing=$missing, top=[$freq]")
                }
            }

            if (numericSeries.size >= 2) {
                sb.appendLine()
                sb.appendLine("Pairwise Correlations (Pearson r):")
                val keys = numericSeries.keys.toList()
                for (i in 0 until keys.size) {
                    for (j in i + 1 until keys.size) {
                        val a = numericSeries[keys[i]]!!
                        val b = numericSeries[keys[j]]!!
                        if (a.size == b.size && a.size >= 3) {
                            val r = pearson(a, b)
                            if (!r.isNaN()) {
                                sb.appendLine("  - ${keys[i]} vs ${keys[j]}: r = ${fmt(r)}")
                            }
                        }
                    }
                }
            }

            PluginExecutionResult(
                pluginId = "data_analyzer",
                pluginName = "Complex Data & CSV Profiler",
                success = true,
                summary = "Profiled ${rows.size} rows x ${headers.size} cols",
                output = sb.toString().trim()
            )
        } catch (e: Exception) {
            PluginExecutionResult("data_analyzer", "Complex Data & CSV Profiler", false, "Parse error", e.message ?: "Failed")
        }
    }

    private fun parseDelimitedTable(text: String): Pair<List<String>, List<List<String>>> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList<String>() to emptyList()
        val delimiter = when {
            lines.first().contains('\t') -> '\t'
            lines.first().contains(';') -> ';'
            else -> ','
        }
        val headers = lines.first().split(delimiter).map { it.trim().removeSurrounding("\"") }
        val rows = lines.drop(1).map { line ->
            line.split(delimiter).map { it.trim().removeSurrounding("\"") }
        }
        return headers to rows
    }

    private fun parseJsonArrayTable(text: String): Pair<List<String>, List<List<String>>> {
        val arr = JSONArray(text)
        val headerSet = linkedSetOf<String>()
        val objects = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            objects.add(obj)
            val keys = obj.keys()
            while (keys.hasNext()) headerSet.add(keys.next())
        }
        val headers = headerSet.toList()
        val rows = objects.map { obj -> headers.map { key -> obj.opt(key)?.toString() ?: "" } }
        return headers to rows
    }

    private fun pearson(xs: List<Double>, ys: List<Double>): Double {
        val meanX = xs.average()
        val meanY = ys.average()
        var num = 0.0
        var denX = 0.0
        var denY = 0.0
        for (i in xs.indices) {
            val dx = xs[i] - meanX
            val dy = ys[i] - meanY
            num += dx * dy
            denX += dx * dx
            denY += dy * dy
        }
        val den = sqrt(denX * denY)
        return if (den == 0.0) Double.NaN else num / den
    }

    private fun fmt(value: Double): String {
        val rounded = round(value * 1000.0) / 1000.0
        return if (rounded % 1.0 == 0.0 && abs(rounded) < 1e12) {
            rounded.toLong().toString()
        } else {
            rounded.toString()
        }
    }

    fun runCalculator(expression: String): PluginExecutionResult {
        if (expression.isBlank()) {
            return PluginExecutionResult("calculator", "Precision Math Engine", false, "Empty expression", "Provide a math expression.")
        }
        return try {
            val result = ExpressionParser(expression).parse()
            val formatted = fmt(result)
            PluginExecutionResult(
                pluginId = "calculator",
                pluginName = "Precision Math Engine",
                success = true,
                summary = "$expression = $formatted",
                output = "Expression: $expression\nResult: $formatted"
            )
        } catch (e: Exception) {
            PluginExecutionResult("calculator", "Precision Math Engine", false, "Eval error", e.message ?: "Invalid math expression")
        }
    }

    suspend fun runWebFetcher(url: String): PluginExecutionResult = withContext(Dispatchers.IO) {
        val cleanUrl = url.trim()
        if (!cleanUrl.startsWith("https://") && !cleanUrl.startsWith("http://")) {
            return@withContext PluginExecutionResult("web_fetcher", "Live Web & API Fetcher", false, "Invalid URL", "URL must start with https:// or http://")
        }
        try {
            val req = Request.Builder()
                .url(cleanUrl)
                .get()
                .header("User-Agent", "MirzaAi-Workspace/1.0")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty().take(50_000)
                if (!resp.isSuccessful) {
                    return@withContext PluginExecutionResult("web_fetcher", "Live Web & API Fetcher", false, "HTTP ${resp.code}", raw.take(400))
                }
                val contentType = resp.header("Content-Type").orEmpty()
                val cleaned = if (contentType.contains("json", ignoreCase = true) || raw.trimStart().startsWith("{") || raw.trimStart().startsWith("[")) {
                    try {
                        if (raw.trimStart().startsWith("{")) JSONObject(raw).toString(2).take(6000)
                        else JSONArray(raw).toString(2).take(6000)
                    } catch (_: Exception) {
                        raw.take(6000)
                    }
                } else {
                    raw.replace(Regex("<script[\\s\\S]*?</script>", RegexOption.IGNORE_CASE), " ")
                        .replace(Regex("<style[\\s\\S]*?</style>", RegexOption.IGNORE_CASE), " ")
                        .replace(Regex("<[^>]+>"), " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()
                        .take(6000)
                }
                PluginExecutionResult(
                    pluginId = "web_fetcher",
                    pluginName = "Live Web & API Fetcher",
                    success = true,
                    summary = "Fetched ${cleaned.length} chars from ${cleanUrl.take(45)}",
                    output = "URL: $cleanUrl\nHTTP: ${resp.code}\n\n$cleaned"
                )
            }
        } catch (e: Exception) {
            PluginExecutionResult("web_fetcher", "Live Web & API Fetcher", false, "Network error", e.message ?: "Request failed")
        }
    }

    fun runCodeRegexTool(mode: String, input: String, pattern: String): PluginExecutionResult {
        return when (mode.lowercase()) {
            "json_validate" -> try {
                val trimmed = input.trim()
                val formatted = if (trimmed.startsWith("[")) JSONArray(trimmed).toString(2) else JSONObject(trimmed).toString(2)
                PluginExecutionResult("code_regex_tool", "Code & Regex Workbench", true, "Valid JSON (${formatted.lines().size} lines)", formatted.take(6000))
            } catch (e: Exception) {
                PluginExecutionResult("code_regex_tool", "Code & Regex Workbench", false, "Invalid JSON", e.message ?: "Syntax error")
            }
            "regex" -> try {
                val regex = Regex(pattern)
                val matches = regex.findAll(input).take(30).toList()
                val detail = matches.mapIndexed { idx, m ->
                    val groups = m.groupValues.drop(1)
                    if (groups.isEmpty()) "${idx + 1}. '${m.value}' @ [${m.range}]"
                    else "${idx + 1}. '${m.value}' groups=$groups"
                }.joinToString("\n")
                PluginExecutionResult(
                    "code_regex_tool",
                    "Code & Regex Workbench",
                    true,
                    "Matched ${matches.size} occurrence(s)",
                    if (detail.isBlank()) "No matches found for /$pattern/." else detail
                )
            } catch (e: Exception) {
                PluginExecutionResult("code_regex_tool", "Code & Regex Workbench", false, "Regex error", e.message ?: "Invalid regex")
            }
            else -> {
                val lines = input.lines()
                val nonEmpty = lines.count { it.isNotBlank() }
                val words = input.trim().split(Regex("\\s+")).count { it.isNotBlank() }
                val chars = input.length
                val estTokens = (chars / 3.8).toInt().coerceAtLeast(1)
                PluginExecutionResult(
                    "code_regex_tool",
                    "Code & Regex Workbench",
                    true,
                    "$nonEmpty non-empty lines, ~$estTokens tokens",
                    "Total lines: ${lines.size}\nNon-empty lines: $nonEmpty\nWords: $words\nCharacters: $chars\nEstimated LLM tokens: ~$estTokens"
                )
            }
        }
    }

    private suspend fun runWorkspaceMemory(
        userId: String,
        action: String,
        title: String,
        content: String,
        tag: String,
    ): PluginExecutionResult {
        if (userId.isBlank()) {
            return PluginExecutionResult("workspace_memory", "Cloud Workspace Memory", false, "Not signed in", "Sign in required.")
        }
        return if (action.equals("save", ignoreCase = true)) {
            val res = cloudRepository.addMemory(userId, title.ifBlank { "AI Insight" }, content.ifBlank { title }, tag)
            if (res.isSuccess) {
                PluginExecutionResult("workspace_memory", "Cloud Workspace Memory", true, "Saved '$title' to Cloud", "Saved memory '${title.ifBlank { "AI Insight" }}' synced to Firebase Cloud.")
            } else {
                PluginExecutionResult("workspace_memory", "Cloud Workspace Memory", false, "Save failed", res.exceptionOrNull()?.message ?: "Error")
            }
        } else {
            val res = cloudRepository.listMemoriesOnce(userId)
            val list = res.getOrElse { emptyList() }
            val text = if (list.isEmpty()) {
                "No workspace memories stored yet."
            } else {
                list.take(15).joinToString("\n") { "- [${it.tag}] ${it.title}: ${it.content}" }
            }
            PluginExecutionResult("workspace_memory", "Cloud Workspace Memory", true, "Loaded ${list.size} cloud memories", text)
        }
    }

    fun runDateTimePlanner(timezone: String, fromDate: String, toDate: String): PluginExecutionResult {
        return try {
            val zone = try { ZoneId.of(timezone.ifBlank { "Asia/Jakarta" }) } catch (_: Exception) { ZoneId.of("UTC") }
            val now = ZonedDateTime.now(zone)
            val formattedNow = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z (EEEE)"))
            val sb = StringBuilder("Current time in $zone: $formattedNow\nISO-8601 UTC: ${Instant.now()}")
            if (fromDate.isNotBlank() && toDate.isNotBlank()) {
                val d1 = java.time.LocalDate.parse(fromDate.trim())
                val d2 = java.time.LocalDate.parse(toDate.trim())
                val days = ChronoUnit.DAYS.between(d1, d2)
                sb.append("\nDays between $d1 and $d2: $days days")
            }
            PluginExecutionResult("datetime_planner", "DateTime & Timezone Planner", true, formattedNow, sb.toString())
        } catch (e: Exception) {
            PluginExecutionResult("datetime_planner", "DateTime & Timezone Planner", false, "Date error", e.message ?: "Invalid date or timezone")
        }
    }

    private class ExpressionParser(private val input: String) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() {
            ch = if (++pos < input.length) input[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < input.length) throw IllegalArgumentException("Unexpected character: '${ch.toChar()}'")
            return x
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> {
                        val d = parseFactor()
                        if (d == 0.0) throw ArithmeticException("Division by zero")
                        x /= d
                    }
                    eat('%'.code) -> x %= parseFactor()
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()
            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                if (!eat(')'.code)) throw IllegalArgumentException("Missing closing ')'")
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                x = input.substring(startPos, pos).toDouble()
            } else if (ch in 'a'.code..'z'.code || ch in 'A'.code..'Z'.code) {
                while (ch in 'a'.code..'z'.code || ch in 'A'.code..'Z'.code) nextChar()
                val func = input.substring(startPos, pos).lowercase()
                x = when (func) {
                    "pi" -> Math.PI
                    "e" -> Math.E
                    else -> {
                        val arg = parseFactor()
                        when (func) {
                            "sqrt" -> sqrt(arg)
                            "sin" -> sin(Math.toRadians(arg))
                            "cos" -> cos(Math.toRadians(arg))
                            "tan" -> tan(Math.toRadians(arg))
                            "log" -> log10(arg)
                            "ln" -> ln(arg)
                            "abs" -> abs(arg)
                            "round" -> round(arg)
                            else -> throw IllegalArgumentException("Unknown function: $func")
                        }
                    }
                }
            } else {
                throw IllegalArgumentException("Unexpected character: '${ch.toChar()}'")
            }
            if (eat('^'.code)) x = x.pow(parseFactor())
            return x
        }
    }
}

object DefaultSkills {
    val starterTemplates: List<AiSkill> = listOf(
        AiSkill(
            name = "Complex Data Scientist",
            slashCommand = "/analyze",
            category = SkillCategory.DATA.name,
            description = "Deep statistical analysis, anomaly detection, correlation insights, and executive data tables.",
            systemPrompt = "You are MirzaAi Data Scientist. Always inspect raw data using the data_analyzer and calculator plugins before drawing conclusions. Present findings with structured markdown tables, exact metrics, anomalies, and actionable recommendations.",
            preferredModelId = "anthropic/claude-3.7-sonnet",
            temperature = 0.2,
            workflowSteps = listOf(
                "Audit schema, data quality, missing values, and run statistical profiling on the input data.",
                "Identify key drivers, correlations, outliers, and growth rates using exact calculations.",
                "Produce an executive summary with clear recommendations and next actions."
            ),
            attachedPluginIds = listOf("data_analyzer", "calculator", "workspace_memory"),
            enabled = true
        ),
        AiSkill(
            name = "Automated Research Pipeline",
            slashCommand = "/research",
            category = SkillCategory.AUTOMATION.name,
            description = "3-step autonomous workflow: fetches live sources, extracts facts, and synthesizes a briefing.",
            systemPrompt = "You are MirzaAi Autonomous Researcher. Gather verified facts using web_fetcher when URLs are supplied, cross-check numbers, and output a crisp, well-cited briefing.",
            preferredModelId = "google/gemini-2.5-pro-preview",
            temperature = 0.3,
            workflowSteps = listOf(
                "Deconstruct the research topic into core questions and retrieve available context/URLs.",
                "Cross-analyze evidence, compare trade-offs, and highlight uncertainties.",
                "Compile a structured final brief with key takeaways and action items."
            ),
            attachedPluginIds = listOf("web_fetcher", "workspace_memory", "datetime_planner"),
            enabled = true
        ),
        AiSkill(
            name = "Principal Code Architect",
            slashCommand = "/architect",
            category = SkillCategory.CODING.name,
            description = "Claude-style senior software architecture review, refactoring, and edge-case verification.",
            systemPrompt = "You are MirzaAi Principal Architect. Write clean, production-grade code, explain architectural trade-offs concisely, and verify JSON/regex/code metrics via code_regex_tool when relevant.",
            preferredModelId = "anthropic/claude-3.7-sonnet",
            temperature = 0.2,
            workflowSteps = emptyList(),
            attachedPluginIds = listOf("code_regex_tool", "calculator"),
            enabled = true
        ),
        AiSkill(
            name = "Executive Summary & Action Plan",
            slashCommand = "/brief",
            category = SkillCategory.WRITING.name,
            description = "Distills dense reports or transcripts into clear bullet points, risks, and owner timelines.",
            systemPrompt = "Transform complex inputs into a crisp executive brief: 1) TL;DR, 2) Key Metrics, 3) Risks & Mitigations, 4) Prioritized Action Plan.",
            preferredModelId = "anthropic/claude-3.5-haiku",
            temperature = 0.35,
            workflowSteps = listOf(
                "Extract all key facts, metrics, and stakeholders from the source content.",
                "Format into an executive brief with prioritized next steps and timelines."
            ),
            attachedPluginIds = listOf("datetime_planner", "workspace_memory"),
            enabled = true
        ),
    )
}
