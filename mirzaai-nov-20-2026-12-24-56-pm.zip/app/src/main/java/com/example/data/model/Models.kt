package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light Paper"),
    DARK("Obsidian Dark");

    companion object {
        fun fromRaw(raw: String?): ThemeMode =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: SYSTEM
    }
}

enum class ResponseLanguage(val label: String, val instruction: String) {
    AUTO("Auto (Match User)", ""),
    ID("Bahasa Indonesia", "Respond naturally and clearly in Bahasa Indonesia unless asked otherwise."),
    EN("English", "Respond clearly and concisely in English unless asked otherwise.");

    companion object {
        fun fromRaw(raw: String?): ResponseLanguage =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: AUTO
    }
}

enum class SkillCategory(val label: String) {
    DATA("Data Analysis"),
    CODING("Engineering"),
    RESEARCH("Research"),
    AUTOMATION("Workflow"),
    WRITING("Writing"),
    CUSTOM("Custom");

    companion object {
        fun fromRaw(raw: String?): SkillCategory =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: CUSTOM
    }
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

// --- FIRESTORE DATA MODELS (No-arg defaults, @Keep, @IgnoreExtraProperties, @DocumentId, no 'is'-prefixed Booleans) ---

@Keep
@IgnoreExtraProperties
data class UserSettings(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Mirza User",
    val preferredModelId: String = "anthropic/claude-3.7-sonnet",
    val customInstructions: String = "",
    val themeMode: String = ThemeMode.SYSTEM.name,
    val responseLanguage: String = ResponseLanguage.AUTO.name,
    val temperature: Double = 0.4,
    val maxTokens: Long = 4096L,
    val streamingEnabled: Boolean = true,
    val showReasoning: Boolean = true,
    val enabledPluginIds: List<String> = listOf(
        "data_analyzer",
        "calculator",
        "web_fetcher",
        "code_regex_tool",
        "workspace_memory",
        "datetime_planner"
    ),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "New Conversation",
    val modelId: String = "anthropic/claude-3.7-sonnet",
    val activeSkillId: String = "",
    val lastMessagePreview: String = "",
    val pinned: Boolean = false,
    val messageCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val role: String = "user",
    val content: String = "",
    val reasoning: String = "",
    val modelId: String = "",
    val skillName: String = "",
    val attachmentSummary: String = "",
    val pluginLog: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AiSkill(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val slashCommand: String = "",
    val category: String = SkillCategory.CUSTOM.name,
    val description: String = "",
    val systemPrompt: String = "",
    val preferredModelId: String = "",
    val temperature: Double = 0.3,
    val workflowSteps: List<String> = emptyList(),
    val attachedPluginIds: List<String> = emptyList(),
    val enabled: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class WorkspaceMemory(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val tag: String = "general",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

// --- OPENROUTER & PLUGIN DOMAIN MODELS ---

data class OpenRouterModel(
    val id: String,
    val name: String,
    val provider: String,
    val description: String,
    val contextLength: Int,
    val promptPricePerMillion: Double,
    val completionPricePerMillion: Double,
    val supportsVision: Boolean,
    val supportsTools: Boolean,
    val supportsReasoning: Boolean,
    val isFree: Boolean,
)

data class PluginDefinition(
    val id: String,
    val name: String,
    val shortDescription: String,
    val category: String,
    val sampleInputLabel: String,
    val sampleInputDefault: String,
    val parametersHint: String,
)

data class PluginExecutionResult(
    val pluginId: String,
    val pluginName: String,
    val success: Boolean,
    val summary: String,
    val output: String,
)

data class PendingAttachment(
    val id: String,
    val fileName: String,
    val mimeType: String,
    val isImage: Boolean,
    val textContent: String = "",
    val imageBase64DataUrl: String = "",
    val sizeBytes: Long = 0L,
    val localDataProfile: String = "",
)

data class WorkflowProgress(
    val skillName: String,
    val currentStepIndex: Int,
    val totalSteps: Int,
    val currentStepLabel: String,
)
