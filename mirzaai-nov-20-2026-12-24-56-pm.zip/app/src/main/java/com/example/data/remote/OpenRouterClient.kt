package com.example.data.remote

import com.example.BuildConfig
import com.example.data.model.OpenRouterModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class ToolCallRequest(
    val id: String,
    val name: String,
    val argumentsJson: String,
)

data class OpenRouterTurnResult(
    val content: String,
    val reasoning: String,
    val toolCalls: List<ToolCallRequest>,
    val finishReason: String,
)

class OpenRouterClient(
    private val customKeyProvider: () -> String? = { null },
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    private val baseUrl = "https://openrouter.ai/api/v1"
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun resolveApiKey(): String {
        val local = customKeyProvider()?.trim().orEmpty()
        if (local.isNotBlank()) return local
        val buildKey = BuildConfig.OPENROUTER_API_KEY.trim()
        return if (buildKey != "YOUR_OPENROUTER_API_KEY") buildKey else ""
    }

    fun hasValidApiKey(): Boolean = resolveApiKey().isNotBlank()

    suspend fun fetchAllModels(): Result<List<OpenRouterModel>> = withContext(Dispatchers.IO) {
        try {
            val reqBuilder = Request.Builder()
                .url("$baseUrl/models")
                .get()
                .header("Accept", "application/json")
            val activeKey = resolveApiKey()
            if (activeKey.isNotBlank()) {
                reqBuilder.header("Authorization", "Bearer $activeKey")
            }
            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("OpenRouter models HTTP ${response.code}: ${body.take(240)}")
                    )
                }
                val models = OpenRouterCatalog.parseModelsResponse(body)
                Result.success(models.ifEmpty { OpenRouterCatalog.fallbackModels })
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendChatCompletion(
        modelId: String,
        messagesJson: JSONArray,
        toolsJson: JSONArray?,
        temperature: Double,
        maxTokens: Int,
        stream: Boolean,
        onStreamDelta: (contentDelta: String, reasoningDelta: String) -> Unit = { _, _ -> },
    ): Result<OpenRouterTurnResult> = withContext(Dispatchers.IO) {
        val activeKey = resolveApiKey()
        if (activeKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("OpenRouter API key is not set. Paste your key in Studio or configure OPENROUTER_API_KEY in Secrets.")
            )
        }

        try {
            val payload = JSONObject().apply {
                put("model", modelId)
                put("messages", messagesJson)
                put("temperature", temperature.coerceIn(0.0, 2.0))
                put("max_tokens", maxTokens.coerceIn(128, 32768))
                put("stream", stream)
                if (toolsJson != null && toolsJson.length() > 0) {
                    put("tools", toolsJson)
                    put("tool_choice", "auto")
                }
            }

            val request = Request.Builder()
                .url("$baseUrl/chat/completions")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .header("Authorization", "Bearer $activeKey")
                .header("Content-Type", "application/json")
                .header("HTTP-Referer", "https://mirzaai.app")
                .header("X-Title", "MirzaAi Studio")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty()
                    val parsedErr = try {
                        JSONObject(errBody).optJSONObject("error")?.optString("message") ?: errBody
                    } catch (_: Exception) {
                        errBody
                    }
                    return@withContext Result.failure(
                        IllegalStateException("OpenRouter (${response.code}): ${parsedErr.take(300)}")
                    )
                }

                if (!stream) {
                    val raw = response.body?.string().orEmpty()
                    return@withContext Result.success(parseNonStreamingResponse(raw))
                }

                val bodyStream = response.body?.byteStream()
                    ?: return@withContext Result.failure(IllegalStateException("Empty response stream"))

                val contentBuilder = StringBuilder()
                val reasoningBuilder = StringBuilder()
                val toolAccumulators = linkedMapOf<Int, Triple<StringBuilder, StringBuilder, StringBuilder>>()
                var finishReason = "stop"

                BufferedReader(InputStreamReader(bodyStream, Charsets.UTF_8)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val trimmed = line?.trim().orEmpty()
                        if (!trimmed.startsWith("data:")) continue
                        val data = trimmed.removePrefix("data:").trim()
                        if (data == "[DONE]" || data.isEmpty()) continue

                        val chunk = try {
                            JSONObject(data)
                        } catch (_: Exception) {
                            continue
                        }

                        val choices = chunk.optJSONArray("choices") ?: continue
                        if (choices.length() == 0) continue
                        val choice = choices.optJSONObject(0) ?: continue
                        val fr = choice.optString("finish_reason", "")
                        if (fr.isNotBlank() && fr != "null") finishReason = fr

                        val delta = choice.optJSONObject("delta") ?: continue
                        val cDelta = delta.optString("content", "")
                            .let { if (it == "null") "" else it }
                        val rDelta = (delta.optString("reasoning", "").takeIf { it.isNotBlank() && it != "null" }
                            ?: delta.optString("reasoning_content", "").takeIf { it.isNotBlank() && it != "null" }
                            ?: "")

                        if (cDelta.isNotEmpty() || rDelta.isNotEmpty()) {
                            contentBuilder.append(cDelta)
                            reasoningBuilder.append(rDelta)
                            onStreamDelta(cDelta, rDelta)
                        }

                        val toolCalls = delta.optJSONArray("tool_calls")
                        if (toolCalls != null) {
                            for (i in 0 until toolCalls.length()) {
                                val tc = toolCalls.optJSONObject(i) ?: continue
                                val index = tc.optInt("index", i)
                                val acc = toolAccumulators.getOrPut(index) {
                                    Triple(StringBuilder(), StringBuilder(), StringBuilder())
                                }
                                val idPart = tc.optString("id", "")
                                if (idPart.isNotBlank() && idPart != "null") acc.first.append(idPart)
                                val fn = tc.optJSONObject("function")
                                if (fn != null) {
                                    val namePart = fn.optString("name", "")
                                    if (namePart.isNotBlank() && namePart != "null") acc.second.append(namePart)
                                    val argPart = fn.optString("arguments", "")
                                    if (argPart.isNotBlank() && argPart != "null") acc.third.append(argPart)
                                }
                            }
                        }
                    }
                }

                val parsedCalls = toolAccumulators.entries.sortedBy { it.key }.map { (idx, triple) ->
                    ToolCallRequest(
                        id = triple.first.toString().ifBlank { "call_$idx" },
                        name = triple.second.toString(),
                        argumentsJson = triple.third.toString().ifBlank { "{}" }
                    )
                }.filter { it.name.isNotBlank() }

                Result.success(
                    OpenRouterTurnResult(
                        content = contentBuilder.toString(),
                        reasoning = reasoningBuilder.toString(),
                        toolCalls = parsedCalls,
                        finishReason = finishReason
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseNonStreamingResponse(raw: String): OpenRouterTurnResult {
        val root = JSONObject(raw)
        val choice = root.optJSONArray("choices")?.optJSONObject(0)
            ?: return OpenRouterTurnResult("", "", emptyList(), "stop")
        val finishReason = choice.optString("finish_reason", "stop")
        val message = choice.optJSONObject("message")
            ?: return OpenRouterTurnResult("", "", emptyList(), finishReason)

        val content = message.optString("content", "").let { if (it == "null") "" else it }
        val reasoning = (message.optString("reasoning", "").takeIf { it.isNotBlank() && it != "null" }
            ?: message.optString("reasoning_content", "").takeIf { it.isNotBlank() && it != "null" }
            ?: "")

        val calls = mutableListOf<ToolCallRequest>()
        val tcArray = message.optJSONArray("tool_calls")
        if (tcArray != null) {
            for (i in 0 until tcArray.length()) {
                val tc = tcArray.optJSONObject(i) ?: continue
                val fn = tc.optJSONObject("function") ?: continue
                val name = fn.optString("name", "")
                if (name.isNotBlank()) {
                    calls.add(
                        ToolCallRequest(
                            id = tc.optString("id", "call_$i"),
                            name = name,
                            argumentsJson = fn.optString("arguments", "{}")
                        )
                    )
                }
            }
        }
        return OpenRouterTurnResult(content, reasoning, calls, finishReason)
    }
}
