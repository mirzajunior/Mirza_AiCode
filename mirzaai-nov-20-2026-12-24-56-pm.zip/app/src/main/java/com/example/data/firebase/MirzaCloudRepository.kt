package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.AiSkill
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.ResponseLanguage
import com.example.data.model.SkillCategory
import com.example.data.model.ThemeMode
import com.example.data.model.UserSettings
import com.example.data.model.WorkspaceMemory
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class MirzaCloudRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireAuthorizedUser(userId: String): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        check(uid == userId) { "Signed-in user changed; refusing cross-user access." }
        return uid
    }

    private fun userDoc(userId: String) = db.collection("users").document(userId)

    // --- REAL-TIME OBSERVERS ---

    fun observeSettings(userId: String): Flow<UserSettings?> =
        userDoc(userId).snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                rethrowOrLog(error, OperationType.GET, "users/$userId", userId)
            }

    fun observeConversations(userId: String): Flow<List<Conversation>> =
        userDoc(userId).collection("conversations")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(
                        compareByDescending<Conversation> { it.pinned }
                            .thenByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                    )
            }
            .catch { error ->
                rethrowOrLog(error, OperationType.LIST, "users/$userId/conversations", userId)
            }

    fun observeMessages(userId: String, conversationId: String): Flow<List<ChatMessage>> =
        userDoc(userId).collection("conversations").document(conversationId).collection("messages")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(Long.MAX_VALUE / 2, 0) }
            }
            .catch { error ->
                rethrowOrLog(
                    error,
                    OperationType.LIST,
                    "users/$userId/conversations/$conversationId/messages",
                    userId
                )
            }

    fun observeSkills(userId: String): Flow<List<AiSkill>> =
        userDoc(userId).collection("skills")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(AiSkill::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                rethrowOrLog(error, OperationType.LIST, "users/$userId/skills", userId)
            }

    fun observeMemories(userId: String): Flow<List<WorkspaceMemory>> =
        userDoc(userId).collection("memories")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(WorkspaceMemory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                rethrowOrLog(error, OperationType.LIST, "users/$userId/memories", userId)
            }

    private fun rethrowOrLog(error: Throwable, op: OperationType, path: String, expectedUid: String): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
        throw error
    }

    // --- SETTINGS MUTATIONS ---

    suspend fun ensureUserSettings(userId: String, displayName: String): Result<Unit> =
        runSafeMutation(OperationType.CREATE, "users/$userId") {
            val uid = requireAuthorizedUser(userId)
            val ref = userDoc(uid)
            val snap = ref.get().await()
            if (!snap.exists()) {
                val cleanName = displayName.trim().ifBlank { "Mirza User" }.take(100)
                val defaults = UserSettings(displayName = cleanName)
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to cleanName,
                    "preferredModelId" to defaults.preferredModelId,
                    "customInstructions" to defaults.customInstructions,
                    "themeMode" to ThemeMode.SYSTEM.name,
                    "responseLanguage" to ResponseLanguage.AUTO.name,
                    "temperature" to defaults.temperature,
                    "maxTokens" to defaults.maxTokens,
                    "streamingEnabled" to defaults.streamingEnabled,
                    "showReasoning" to defaults.showReasoning,
                    "enabledPluginIds" to defaults.enabledPluginIds,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                ref.set(payload).await()
            }
        }

    suspend fun updateSettings(userId: String, settings: UserSettings): Result<Unit> =
        runSafeMutation(OperationType.UPDATE, "users/$userId") {
            val uid = requireAuthorizedUser(userId)
            val payload = mapOf(
                "displayName" to settings.displayName.trim().ifBlank { "Mirza User" }.take(100),
                "preferredModelId" to settings.preferredModelId.trim().ifBlank { "anthropic/claude-3.7-sonnet" }.take(160),
                "customInstructions" to settings.customInstructions.take(4000),
                "themeMode" to ThemeMode.fromRaw(settings.themeMode).name,
                "responseLanguage" to ResponseLanguage.fromRaw(settings.responseLanguage).name,
                "temperature" to settings.temperature.coerceIn(0.0, 2.0),
                "maxTokens" to settings.maxTokens.coerceIn(128L, 32768L),
                "streamingEnabled" to settings.streamingEnabled,
                "showReasoning" to settings.showReasoning,
                "enabledPluginIds" to settings.enabledPluginIds.distinct().take(20),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            userDoc(uid).update(payload).await()
        }

    // --- CONVERSATION & MESSAGE MUTATIONS ---

    suspend fun createConversation(
        userId: String,
        title: String,
        modelId: String,
        activeSkillId: String = "",
    ): Result<String> = runSafeMutation(OperationType.CREATE, "users/$userId/conversations") {
        val uid = requireAuthorizedUser(userId)
        val convId = "conv_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val safeTitle = title.trim().ifBlank { "New Conversation" }.take(200)
        val safeModel = modelId.trim().ifBlank { "anthropic/claude-3.7-sonnet" }.take(160)
        val payload = mapOf(
            "userId" to uid,
            "title" to safeTitle,
            "modelId" to safeModel,
            "activeSkillId" to activeSkillId.take(128),
            "lastMessagePreview" to "",
            "pinned" to false,
            "messageCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )
        userDoc(uid).collection("conversations").document(convId).set(payload).await()
        convId
    }

    suspend fun updateConversationMetadata(
        userId: String,
        conversationId: String,
        title: String? = null,
        modelId: String? = null,
        activeSkillId: String? = null,
        lastMessagePreview: String? = null,
        pinned: Boolean? = null,
        messageCount: Long? = null,
    ): Result<Unit> = runSafeMutation(
        OperationType.UPDATE,
        "users/$userId/conversations/$conversationId"
    ) {
        val uid = requireAuthorizedUser(userId)
        require(conversationId.isNotBlank()) { "Conversation ID must not be blank" }
        val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
        if (title != null) updates["title"] = title.trim().ifBlank { "Untitled" }.take(200)
        if (modelId != null) updates["modelId"] = modelId.trim().ifBlank { "anthropic/claude-3.7-sonnet" }.take(160)
        if (activeSkillId != null) updates["activeSkillId"] = activeSkillId.take(128)
        if (lastMessagePreview != null) updates["lastMessagePreview"] = lastMessagePreview.take(300)
        if (pinned != null) updates["pinned"] = pinned
        if (messageCount != null) updates["messageCount"] = messageCount.coerceIn(0L, 10000L)
        userDoc(uid).collection("conversations").document(conversationId).update(updates).await()
    }

    suspend fun deleteConversation(userId: String, conversationId: String): Result<Unit> =
        runSafeMutation(OperationType.DELETE, "users/$userId/conversations/$conversationId") {
            val uid = requireAuthorizedUser(userId)
            val convRef = userDoc(uid).collection("conversations").document(conversationId)
            val msgs = convRef.collection("messages").get().await()
            if (!msgs.isEmpty) {
                val batch = db.batch()
                msgs.documents.forEach { batch.delete(it.reference) }
                batch.delete(convRef)
                batch.commit().await()
            } else {
                convRef.delete().await()
            }
        }

    suspend fun addMessage(
        userId: String,
        conversationId: String,
        role: String,
        content: String,
        reasoning: String = "",
        modelId: String = "",
        skillName: String = "",
        attachmentSummary: String = "",
        pluginLog: String = "",
    ): Result<String> = runSafeMutation(
        OperationType.CREATE,
        "users/$userId/conversations/$conversationId/messages"
    ) {
        val uid = requireAuthorizedUser(userId)
        require(conversationId.isNotBlank()) { "Conversation ID must not be blank" }
        val safeRole = if (role in setOf("user", "assistant", "tool")) role else "assistant"
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = mapOf(
            "userId" to uid,
            "role" to safeRole,
            "content" to content.take(100000),
            "reasoning" to reasoning.take(50000),
            "modelId" to modelId.take(160),
            "skillName" to skillName.take(120),
            "attachmentSummary" to attachmentSummary.take(500),
            "pluginLog" to pluginLog.take(20000),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )
        userDoc(uid).collection("conversations").document(conversationId)
            .collection("messages").document(msgId)
            .set(payload)
            .await()
        msgId
    }

    // --- SKILL & WORKFLOW MUTATIONS ---

    suspend fun upsertSkill(userId: String, skill: AiSkill): Result<String> {
        val isCreate = skill.id.isBlank()
        val skillId = if (isCreate) {
            "skill_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        } else {
            skill.id
        }
        val path = "users/$userId/skills/$skillId"
        return runSafeMutation(if (isCreate) OperationType.CREATE else OperationType.UPDATE, path) {
            val uid = requireAuthorizedUser(userId)
            val cleanName = skill.name.trim().ifBlank { "Custom Skill" }.take(120)
            val cleanCmd = skill.slashCommand.trim()
                .let { if (it.startsWith("/")) it else "/$it" }
                .ifBlank { "/skill" }
                .take(50)
            val cleanPrompt = skill.systemPrompt.trim().ifBlank { "Assist the user effectively." }.take(8000)
            val cleanSteps = skill.workflowSteps.map { it.trim().take(1000) }.filter { it.isNotBlank() }.take(10)
            val cleanPlugins = skill.attachedPluginIds.distinct().take(15)
            val category = SkillCategory.fromRaw(skill.category).name

            val docRef = userDoc(uid).collection("skills").document(skillId)
            if (isCreate) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "name" to cleanName,
                        "slashCommand" to cleanCmd,
                        "category" to category,
                        "description" to skill.description.trim().take(500),
                        "systemPrompt" to cleanPrompt,
                        "preferredModelId" to skill.preferredModelId.trim().take(160),
                        "temperature" to skill.temperature.coerceIn(0.0, 2.0),
                        "workflowSteps" to cleanSteps,
                        "attachedPluginIds" to cleanPlugins,
                        "enabled" to skill.enabled,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "name" to cleanName,
                        "slashCommand" to cleanCmd,
                        "category" to category,
                        "description" to skill.description.trim().take(500),
                        "systemPrompt" to cleanPrompt,
                        "preferredModelId" to skill.preferredModelId.trim().take(160),
                        "temperature" to skill.temperature.coerceIn(0.0, 2.0),
                        "workflowSteps" to cleanSteps,
                        "attachedPluginIds" to cleanPlugins,
                        "enabled" to skill.enabled,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            skillId
        }
    }

    suspend fun toggleSkillEnabled(userId: String, skillId: String, enabled: Boolean): Result<Unit> =
        runSafeMutation(OperationType.UPDATE, "users/$userId/skills/$skillId") {
            val uid = requireAuthorizedUser(userId)
            userDoc(uid).collection("skills").document(skillId)
                .update(
                    mapOf(
                        "enabled" to enabled,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
        }

    suspend fun deleteSkill(userId: String, skillId: String): Result<Unit> =
        runSafeMutation(OperationType.DELETE, "users/$userId/skills/$skillId") {
            val uid = requireAuthorizedUser(userId)
            userDoc(uid).collection("skills").document(skillId).delete().await()
        }

    // --- WORKSPACE MEMORY MUTATIONS ---

    suspend fun addMemory(
        userId: String,
        title: String,
        content: String,
        tag: String = "general",
    ): Result<String> = runSafeMutation(OperationType.CREATE, "users/$userId/memories") {
        val uid = requireAuthorizedUser(userId)
        val memId = "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = mapOf(
            "userId" to uid,
            "title" to title.trim().ifBlank { "Workspace Note" }.take(150),
            "content" to content.trim().ifBlank { "-" }.take(4000),
            "tag" to tag.trim().ifBlank { "general" }.take(60),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )
        userDoc(uid).collection("memories").document(memId).set(payload).await()
        memId
    }

    suspend fun listMemoriesOnce(userId: String): Result<List<WorkspaceMemory>> =
        runSafeMutation(OperationType.LIST, "users/$userId/memories") {
            val uid = requireAuthorizedUser(userId)
            userDoc(uid).collection("memories").get().await()
                .toObjects(WorkspaceMemory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
        }

    suspend fun deleteMemory(userId: String, memoryId: String): Result<Unit> =
        runSafeMutation(OperationType.DELETE, "users/$userId/memories/$memoryId") {
            val uid = requireAuthorizedUser(userId)
            userDoc(uid).collection("memories").document(memoryId).delete().await()
        }

    private suspend inline fun <T> runSafeMutation(
        operationType: OperationType,
        path: String,
        crossinline block: suspend () -> T,
    ): Result<T> {
        return try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, operationType, path)
            Result.failure(e)
        }
    }
}
