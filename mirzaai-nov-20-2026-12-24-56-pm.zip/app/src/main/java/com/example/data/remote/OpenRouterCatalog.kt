package com.example.data.remote

import com.example.data.model.OpenRouterModel
import org.json.JSONObject

object OpenRouterCatalog {

    val fallbackModels: List<OpenRouterModel> = listOf(
        OpenRouterModel(
            id = "anthropic/claude-3.7-sonnet",
            name = "Claude 3.7 Sonnet",
            provider = "Anthropic",
            description = "Hybrid reasoning & premier coding, data analysis, and nuanced writing.",
            contextLength = 200_000,
            promptPricePerMillion = 3.0,
            completionPricePerMillion = 15.0,
            supportsVision = true,
            supportsTools = true,
            supportsReasoning = true,
            isFree = false
        ),
        OpenRouterModel(
            id = "anthropic/claude-3.5-sonnet",
            name = "Claude 3.5 Sonnet",
            provider = "Anthropic",
            description = "Fast, balanced flagship Claude model for analysis and workflows.",
            contextLength = 200_000,
            promptPricePerMillion = 3.0,
            completionPricePerMillion = 15.0,
            supportsVision = true,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "anthropic/claude-3.5-haiku",
            name = "Claude 3.5 Haiku",
            provider = "Anthropic",
            description = "Ultra-fast Anthropic model for responsive automation steps.",
            contextLength = 200_000,
            promptPricePerMillion = 0.8,
            completionPricePerMillion = 4.0,
            supportsVision = true,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "openai/gpt-4o",
            name = "GPT-4o",
            provider = "OpenAI",
            description = "Multimodal OpenAI flagship with strong tool calling and vision.",
            contextLength = 128_000,
            promptPricePerMillion = 2.5,
            completionPricePerMillion = 10.0,
            supportsVision = true,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "openai/o3-mini",
            name = "OpenAI o3-mini",
            provider = "OpenAI",
            description = "Compact STEM, quantitative, and structured reasoning specialist.",
            contextLength = 200_000,
            promptPricePerMillion = 1.1,
            completionPricePerMillion = 4.4,
            supportsVision = false,
            supportsTools = true,
            supportsReasoning = true,
            isFree = false
        ),
        OpenRouterModel(
            id = "google/gemini-2.5-pro-preview",
            name = "Gemini 2.5 Pro",
            provider = "Google",
            description = "1M context reasoning model built for complex datasets and codebases.",
            contextLength = 1_000_000,
            promptPricePerMillion = 1.25,
            completionPricePerMillion = 10.0,
            supportsVision = true,
            supportsTools = true,
            supportsReasoning = true,
            isFree = false
        ),
        OpenRouterModel(
            id = "google/gemini-2.0-flash-001",
            name = "Gemini 2.0 Flash",
            provider = "Google",
            description = "High-efficiency multimodal model with 1M context window.",
            contextLength = 1_000_000,
            promptPricePerMillion = 0.1,
            completionPricePerMillion = 0.4,
            supportsVision = true,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "deepseek/deepseek-r1",
            name = "DeepSeek R1",
            provider = "DeepSeek",
            description = "Open-weights deep reasoning model for math, logic, and complex analysis.",
            contextLength = 163_840,
            promptPricePerMillion = 0.55,
            completionPricePerMillion = 2.19,
            supportsVision = false,
            supportsTools = false,
            supportsReasoning = true,
            isFree = false
        ),
        OpenRouterModel(
            id = "deepseek/deepseek-chat",
            name = "DeepSeek V3",
            provider = "DeepSeek",
            description = "High-value MoE model with strong coding and analytical precision.",
            contextLength = 128_000,
            promptPricePerMillion = 0.27,
            completionPricePerMillion = 1.10,
            supportsVision = false,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "meta-llama/llama-3.3-70b-instruct:free",
            name = "Llama 3.3 70B Instruct (Free)",
            provider = "Meta",
            description = "Free-tier open model suitable for general chat and quick workflows.",
            contextLength = 131_072,
            promptPricePerMillion = 0.0,
            completionPricePerMillion = 0.0,
            supportsVision = false,
            supportsTools = true,
            supportsReasoning = false,
            isFree = true
        ),
        OpenRouterModel(
            id = "qwen/qwen-2.5-72b-instruct",
            name = "Qwen 2.5 72B Instruct",
            provider = "Qwen",
            description = "Multilingual analytical powerhouse strong in structured JSON and math.",
            contextLength = 131_072,
            promptPricePerMillion = 0.35,
            completionPricePerMillion = 0.40,
            supportsVision = false,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "mistralai/mistral-large-2411",
            name = "Mistral Large 2",
            provider = "Mistral",
            description = "Enterprise multilingual reasoning and tool-calling model.",
            contextLength = 128_000,
            promptPricePerMillion = 2.0,
            completionPricePerMillion = 6.0,
            supportsVision = false,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
        OpenRouterModel(
            id = "x-ai/grok-2-1212",
            name = "xAI Grok 2",
            provider = "xAI",
            description = "Fast conversational intelligence with crisp technical synthesis.",
            contextLength = 131_072,
            promptPricePerMillion = 2.0,
            completionPricePerMillion = 10.0,
            supportsVision = false,
            supportsTools = true,
            supportsReasoning = false,
            isFree = false
        ),
    )

    fun parseModelsResponse(jsonBody: String): List<OpenRouterModel> {
        val root = JSONObject(jsonBody)
        val dataArray = root.optJSONArray("data") ?: return fallbackModels
        val parsed = ArrayList<OpenRouterModel>(dataArray.length())

        for (i in 0 until dataArray.length()) {
            val item = dataArray.optJSONObject(i) ?: continue
            val id = item.optString("id", "").trim()
            if (id.isBlank()) continue

            val rawName = item.optString("name", id).trim()
            val providerSlug = id.substringBefore("/", "OpenRouter")
            val provider = formatProviderName(providerSlug)
            val description = item.optString("description", "").trim()
            val contextLength = item.optInt("context_length", 8192)

            val pricing = item.optJSONObject("pricing")
            val promptPerToken = pricing?.optString("prompt", "0")?.toDoubleOrNull() ?: 0.0
            val completionPerToken = pricing?.optString("completion", "0")?.toDoubleOrNull() ?: 0.0
            val promptPerMillion = (promptPerToken * 1_000_000.0).coerceAtLeast(0.0)
            val completionPerMillion = (completionPerToken * 1_000_000.0).coerceAtLeast(0.0)
            val isFree = id.endsWith(":free") || (promptPerMillion == 0.0 && completionPerMillion == 0.0)

            val arch = item.optJSONObject("architecture")
            val inputModalities = arch?.optJSONArray("input_modalities")
            var supportsVision = false
            if (inputModalities != null) {
                for (m in 0 until inputModalities.length()) {
                    if (inputModalities.optString(m) == "image") {
                        supportsVision = true
                        break
                    }
                }
            } else {
                val modality = arch?.optString("modality", "") ?: ""
                supportsVision = modality.contains("image", ignoreCase = true)
            }

            val supportedParams = item.optJSONArray("supported_parameters")
            var supportsTools = false
            var supportsReasoning = id.contains("r1", ignoreCase = true) ||
                id.contains("o1", ignoreCase = true) ||
                id.contains("o3", ignoreCase = true) ||
                id.contains("thinking", ignoreCase = true) ||
                id.contains("claude-3.7", ignoreCase = true)
            if (supportedParams != null) {
                for (p in 0 until supportedParams.length()) {
                    val param = supportedParams.optString(p)
                    if (param == "tools") supportsTools = true
                    if (param == "reasoning" || param == "include_reasoning") supportsReasoning = true
                }
            }

            parsed.add(
                OpenRouterModel(
                    id = id,
                    name = rawName,
                    provider = provider,
                    description = description,
                    contextLength = contextLength,
                    promptPricePerMillion = promptPerMillion,
                    completionPricePerMillion = completionPerMillion,
                    supportsVision = supportsVision,
                    supportsTools = supportsTools,
                    supportsReasoning = supportsReasoning,
                    isFree = isFree
                )
            )
        }

        // Prioritize flagship providers near top while keeping complete OpenRouter catalog searchable
        val priorityOrder = listOf("Anthropic", "OpenAI", "Google", "DeepSeek", "Meta", "Qwen", "Mistral", "xAI")
        return parsed.sortedWith(
            compareBy<OpenRouterModel>(
                { val idx = priorityOrder.indexOf(it.provider); if (idx == -1) 99 else idx },
                { it.name.lowercase() }
            )
        )
    }

    private fun formatProviderName(slug: String): String = when (slug.lowercase()) {
        "anthropic" -> "Anthropic"
        "openai" -> "OpenAI"
        "google" -> "Google"
        "deepseek" -> "DeepSeek"
        "meta-llama" -> "Meta"
        "qwen" -> "Qwen"
        "mistralai" -> "Mistral"
        "x-ai" -> "xAI"
        "cohere" -> "Cohere"
        "perplexity" -> "Perplexity"
        "nvidia" -> "NVIDIA"
        "microsoft" -> "Microsoft"
        else -> slug.replaceFirstChar { it.uppercase() }
    }
}
