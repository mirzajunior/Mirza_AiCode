package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.AiSkill
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.UiState
import com.example.data.model.UserSettings
import com.example.ui.components.MirzaNeuralOrb
import com.example.ui.components.ModelPickerSheet
import com.example.ui.components.RichAssistantContent
import com.example.ui.viewmodel.MirzaViewModel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: MirzaViewModel,
    onOpenSkillsTab: () -> Unit,
    onOpenPluginsTab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val settingsState by viewModel.settingsState.collectAsStateWithLifecycle()
    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val skillsState by viewModel.skillsState.collectAsStateWithLifecycle()
    val allModels by viewModel.allModels.collectAsStateWithLifecycle()
    val isLoadingModels by viewModel.isLoadingModels.collectAsStateWithLifecycle()
    val selectedModelId by viewModel.selectedModelId.collectAsStateWithLifecycle()
    val selectedSkillId by viewModel.selectedSkillId.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val streamingContent by viewModel.streamingContent.collectAsStateWithLifecycle()
    val streamingReasoning by viewModel.streamingReasoning.collectAsStateWithLifecycle()
    val streamingPluginLog by viewModel.streamingPluginLog.collectAsStateWithLifecycle()
    val workflowProgress by viewModel.workflowProgress.collectAsStateWithLifecycle()
    val pendingAttachments by viewModel.pendingAttachments.collectAsStateWithLifecycle()
    val activeConvId by viewModel.activeConversationId.collectAsStateWithLifecycle()
    val hasApiKey by viewModel.hasApiKeyState.collectAsStateWithLifecycle()
    val clipboardManager = LocalClipboardManager.current

    val settings = (settingsState as? UiState.Success)?.data ?: UserSettings()
    val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
    val messages = (messagesState as? UiState.Success)?.data.orEmpty()
    val skills = (skillsState as? UiState.Success)?.data.orEmpty().filter { it.enabled }

    var inputText by remember { mutableStateOf("") }
    var showModelSheet by remember { mutableStateOf(false) }
    var showSkillMenu by remember { mutableStateOf(false) }
    var showTuneDialog by remember { mutableStateOf(false) }
    var showApiKeyDialog by remember { mutableStateOf(false) }
    var manualKeyInput by remember { mutableStateOf("") }
    var drawerSearch by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.attachFileFromUri(context, uri)
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.attachFileFromUri(context, uri)
    }

    LaunchedEffect(messages.size, streamingContent.length) {
        val total = messages.size + if (isGenerating) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem((total - 1).coerceAtLeast(0))
        }
    }

    val activeModel = remember(allModels, selectedModelId) {
        allModels.firstOrNull { it.id == selectedModelId }
    }
    val activeSkill = remember(skills, selectedSkillId) {
        skills.firstOrNull { it.id == selectedSkillId }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(308.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = stringResource(R.string.chat_history_title),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.CloudDone,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = stringResource(R.string.sync_status_live),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                viewModel.startNewConversation()
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.testTag("drawer_new_chat_button")
                        ) {
                            Icon(Icons.Outlined.Add, contentDescription = "New Chat")
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = drawerSearch,
                        onValueChange = { drawerSearch = it },
                        placeholder = { Text("Search chats…") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(Modifier.height(8.dp))

                    val filteredConvs = remember(conversations, drawerSearch) {
                        val q = drawerSearch.trim().lowercase()
                        if (q.isEmpty()) conversations
                        else conversations.filter { it.title.lowercase().contains(q) }
                    }

                    if (filteredConvs.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No synced conversations yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(filteredConvs, key = { it.id }) { conv ->
                                ConversationDrawerItem(
                                    conversation = conv,
                                    isActive = conv.id == activeConvId,
                                    onClick = {
                                        viewModel.openConversation(conv)
                                        scope.launch { drawerState.close() }
                                    },
                                    onTogglePin = { viewModel.togglePinConversation(conv) },
                                    onDelete = { viewModel.deleteConversation(conv.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    ) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .imePadding()
        ) {
            // Top Studio Bar
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = { scope.launch { drawerState.open() } },
                        modifier = Modifier.testTag("open_history_drawer_button")
                    ) {
                        Icon(Icons.Outlined.Menu, contentDescription = "Open conversations")
                    }

                    // Active OpenRouter Model Selector Pill (Claude style)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .padding(horizontal = 4.dp)
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant,
                                RoundedCornerShape(50)
                            )
                            .clickable { showModelSheet = true }
                            .testTag("select_model_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = activeModel?.name ?: selectedModelId.substringAfter("/"),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Outlined.KeyboardArrowDown,
                                contentDescription = "Change model",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showTuneDialog = true },
                            modifier = Modifier.testTag("tune_parameters_button")
                        ) {
                            Icon(Icons.Outlined.Tune, contentDescription = "Tune model parameters")
                        }
                        IconButton(
                            onClick = { viewModel.startNewConversation() },
                            modifier = Modifier.testTag("new_chat_button")
                        ) {
                            Icon(Icons.Outlined.Add, contentDescription = "New chat")
                        }
                    }
                }
            }

            // Missing API key notice with 1-tap clipboard paste or manual entry
            if (!hasApiKey) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.error_missing_openrouter_key),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                val clipText = clipboardManager.getText()?.text?.trim().orEmpty()
                                if (clipText.isNotBlank()) {
                                    viewModel.saveLocalApiKey(clipText)
                                } else {
                                    manualKeyInput = ""
                                    showApiKeyDialog = true
                                }
                            },
                            modifier = Modifier.testTag("paste_api_key_banner_button")
                        ) {
                            Text(
                                text = "Paste Key",
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            // Workflow progress banner
            workflowProgress?.let { progress ->
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(
                            text = "Workflow '${progress.skillName}' • Step ${progress.currentStepIndex}/${progress.totalSteps}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = progress.currentStepLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { progress.currentStepIndex.toFloat() / progress.totalSteps.coerceAtLeast(1) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Message Thread or Editorial Welcome Empty State
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.TopCenter
            ) {
                if (messages.isEmpty() && !isGenerating) {
                    ChatEmptyState(
                        userName = settings.displayName,
                        activeModelName = activeModel?.name ?: selectedModelId,
                        totalModelsCount = allModels.size,
                        activePluginsCount = settings.enabledPluginIds.size,
                        onAttachCsv = {
                            filePickerLauncher.launch(arrayOf("text/*", "application/json", "*/*"))
                        },
                        onQuickPrompt = { promptText -> inputText = promptText },
                        onOpenSkills = onOpenSkillsTab,
                        onOpenPlugins = onOpenPluginsTab,
                        onOpenModels = { showModelSheet = true }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier
                            .widthIn(max = 820.dp)
                            .fillMaxSize()
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            MessageCard(
                                message = msg,
                                showReasoning = settings.showReasoning
                            )
                        }
                        if (isGenerating) {
                            item(key = "streaming_assistant") {
                                StreamingAssistantCard(
                                    modelName = activeModel?.name ?: selectedModelId,
                                    content = streamingContent,
                                    reasoning = streamingReasoning,
                                    pluginLog = streamingPluginLog,
                                    showReasoning = settings.showReasoning
                                )
                            }
                        }
                    }
                }
            }

            // Composer Area
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 820.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    // Pending attachments bar
                    if (pendingAttachments.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            pendingAttachments.forEach { att ->
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (att.isImage) Icons.Outlined.Image else Icons.Outlined.Analytics,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = att.fileName,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Outlined.Close,
                                            contentDescription = "Remove attachment",
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clickable { viewModel.removeAttachment(att.id) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Active Skill + Plugins bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box {
                            FilterChip(
                                selected = activeSkill != null,
                                onClick = { showSkillMenu = true },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = activeSkill?.let { "${it.name} (${it.slashCommand})" } ?: "Skill: Default"
                                    )
                                },
                                modifier = Modifier.testTag("skill_selector_chip")
                            )
                            DropdownMenu(
                                expanded = showSkillMenu,
                                onDismissRequest = { showSkillMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Default MirzaAi") },
                                    onClick = {
                                        viewModel.selectSkill(null)
                                        showSkillMenu = false
                                    }
                                )
                                skills.forEach { skill ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text("${skill.name} (${skill.slashCommand})")
                                                if (skill.workflowSteps.isNotEmpty()) {
                                                    Text(
                                                        "${skill.workflowSteps.size}-step workflow",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            viewModel.selectSkill(skill.id)
                                            showSkillMenu = false
                                        }
                                    )
                                }
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("+ Create Custom Skill…") },
                                    onClick = {
                                        showSkillMenu = false
                                        onOpenSkillsTab()
                                    }
                                )
                            }
                        }

                        FilterChip(
                            selected = settings.enabledPluginIds.isNotEmpty(),
                            onClick = onOpenPluginsTab,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.Extension,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text("${settings.enabledPluginIds.size} Plugins Active") },
                            modifier = Modifier.testTag("plugins_status_chip")
                        )
                    }

                    Spacer(Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = {
                                filePickerLauncher.launch(arrayOf("text/*", "application/json", "*/*"))
                            },
                            modifier = Modifier.testTag("attach_data_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AttachFile,
                                contentDescription = "Attach CSV, JSON, or text file"
                            )
                        }

                        IconButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("attach_image_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Image,
                                contentDescription = "Attach image for vision analysis"
                            )
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    text = stringResource(R.string.chat_placeholder),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            maxLines = 5,
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field")
                        )

                        Surface(
                            color = if ((inputText.isNotBlank() || pendingAttachments.isNotEmpty()) && !isGenerating) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            shape = CircleShape,
                            modifier = Modifier
                                .size(48.dp)
                                .clickable(
                                    enabled = (inputText.isNotBlank() || pendingAttachments.isNotEmpty()) && !isGenerating
                                ) {
                                    val promptToSend = inputText
                                    inputText = ""
                                    viewModel.sendMessage(promptToSend)
                                }
                                .testTag("send_message_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isGenerating) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Send prompt",
                                        tint = if (inputText.isNotBlank() || pendingAttachments.isNotEmpty()) {
                                            MaterialTheme.colorScheme.onPrimary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showModelSheet) {
        ModelPickerSheet(
            models = allModels,
            selectedModelId = selectedModelId,
            isLoading = isLoadingModels,
            onRefresh = { viewModel.refreshOpenRouterModels() },
            onSelectModel = { model -> viewModel.selectModel(model.id) },
            onDismiss = { showModelSheet = false }
        )
    }

    if (showTuneDialog) {
        QuickTuneDialog(
            settings = settings,
            onSave = { updated ->
                viewModel.saveSettings(updated)
                showTuneDialog = false
            },
            onDismiss = { showTuneDialog = false }
        )
    }

    if (showApiKeyDialog) {
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = { Text("OpenRouter API Key") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Key is saved locally on this device only (never synced to cloud).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = manualKeyInput,
                        onValueChange = { manualKeyInput = it },
                        label = { Text("sk-or-v1-...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_api_key_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.saveLocalApiKey(manualKeyInput)
                        showApiKeyDialog = false
                    },
                    enabled = manualKeyInput.isNotBlank()
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ChatEmptyState(
    userName: String,
    activeModelName: String,
    totalModelsCount: Int,
    activePluginsCount: Int,
    onAttachCsv: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onOpenSkills: () -> Unit,
    onOpenPlugins: () -> Unit,
    onOpenModels: () -> Unit,
) {
    Column(
        modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MirzaNeuralOrb(modifier = Modifier.size(86.dp))
        Spacer(Modifier.height(14.dp))
        Text(
            text = "Halo, ${userName.substringBefore(" ")}",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.chat_empty_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "$activeModelName • $totalModelsCount OpenRouter models • $activePluginsCount active plugins",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(22.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionCard(
                title = "Complex Data & CSV Analysis",
                subtitle = "Attach a CSV/JSON file for instant statistical profiling & anomaly insights",
                onClick = onAttachCsv
            )
            QuickActionCard(
                title = "Switch Any OpenRouter Model ($totalModelsCount+)",
                subtitle = "Browse Claude 3.7, GPT-4o, Gemini 2.5, DeepSeek R1, Llama, Qwen & Free models",
                onClick = onOpenModels
            )
            QuickActionCard(
                title = "Customize Skills & Automated Workflows",
                subtitle = "Build multi-step AI pipelines and slash commands synced across devices",
                onClick = onOpenSkills
            )
            QuickActionCard(
                title = "Try MirzaAi Analytical Plugins",
                subtitle = "Analyze sample dataset with built-in Data Profiler & Calculator",
                onClick = {
                    onQuickPrompt("Analyze this quarterly sales CSV using the data_analyzer and calculator plugins and compute MoM growth:\nmonth,revenue,cost\nJan,42000,26000\nFeb,49500,28100\nMar,58200,30400\nApr,64900,31800")
                }
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MessageCard(
    message: ChatMessage,
    showReasoning: Boolean,
) {
    val isUser = message.role == "user"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (isUser) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp),
                modifier = Modifier.widthIn(max = 560.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    if (message.skillName.isNotBlank() || message.attachmentSummary.isNotBlank()) {
                        Text(
                            text = listOfNotNull(
                                message.skillName.takeIf { it.isNotBlank() }?.let { "Skill: $it" },
                                message.attachmentSummary.takeIf { it.isNotBlank() }?.let { "Attached: $it" }
                            ).joinToString(" • "),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        } else {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MirzaNeuralOrb(modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "MirzaAi",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (message.skillName.isNotBlank()) {
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = message.skillName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        if (message.modelId.isNotBlank()) {
                            Text(
                                text = message.modelId.substringAfter("/"),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    RichAssistantContent(
                        content = message.content,
                        reasoning = message.reasoning,
                        pluginLog = message.pluginLog,
                        showReasoningDefault = showReasoning
                    )
                }
            }
        }
    }
}

@Composable
private fun StreamingAssistantCard(
    modelName: String,
    content: String,
    reasoning: String,
    pluginLog: String,
    showReasoning: Boolean,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "MirzaAi ($modelName)…",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.height(10.dp))
            RichAssistantContent(
                content = content.ifBlank { "Analyzing & synthesizing response…" },
                reasoning = reasoning,
                pluginLog = pluginLog,
                showReasoningDefault = showReasoning
            )
        }
    }
}

@Composable
private fun ConversationDrawerItem(
    conversation: Conversation,
    isActive: Boolean,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        color = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surfaceContainerLow,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = conversation.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = conversation.modelId.substringAfter("/"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            IconButton(onClick = onTogglePin, modifier = Modifier.size(34.dp)) {
                Icon(
                    imageVector = Icons.Outlined.PushPin,
                    contentDescription = "Pin conversation",
                    tint = if (conversation.pinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                Icon(
                    imageVector = Icons.Outlined.DeleteOutline,
                    contentDescription = "Delete conversation",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickTuneDialog(
    settings: UserSettings,
    onSave: (UserSettings) -> Unit,
    onDismiss: () -> Unit,
) {
    var temp by remember { mutableStateOf(settings.temperature.toFloat()) }
    var maxTokens by remember { mutableStateOf(settings.maxTokens.toFloat()) }
    var streaming by remember { mutableStateOf(settings.streamingEnabled) }
    var reasoning by remember { mutableStateOf(settings.showReasoning) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Inference Parameters") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column {
                    Text("Temperature: ${(temp * 100).roundToInt() / 100.0}")
                    Slider(
                        value = temp,
                        onValueChange = { temp = it },
                        valueRange = 0f..1.5f
                    )
                }
                Column {
                    Text("Max Output Tokens: ${maxTokens.roundToInt()}")
                    Slider(
                        value = maxTokens,
                        onValueChange = { maxTokens = it },
                        valueRange = 512f..16384f
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Real-time Streaming")
                    Switch(checked = streaming, onCheckedChange = { streaming = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Show Reasoning Trace")
                    Switch(checked = reasoning, onCheckedChange = { reasoning = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    settings.copy(
                        temperature = ((temp * 100).roundToInt() / 100.0),
                        maxTokens = maxTokens.roundToInt().toLong(),
                        streamingEnabled = streaming,
                        showReasoning = reasoning
                    )
                )
            }) {
                Text("Apply & Sync")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
