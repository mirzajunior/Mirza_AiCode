package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.ResponseLanguage
import com.example.data.model.ThemeMode
import com.example.data.model.UiState
import com.example.data.model.UserSettings
import com.example.ui.components.ModelPickerSheet
import com.example.ui.viewmodel.MirzaViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: MirzaViewModel,
    userEmail: String,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val settingsState by viewModel.settingsState.collectAsStateWithLifecycle()
    val allModels by viewModel.allModels.collectAsStateWithLifecycle()
    val isLoadingModels by viewModel.isLoadingModels.collectAsStateWithLifecycle()
    val hasApiKey by viewModel.hasApiKeyState.collectAsStateWithLifecycle()
    val localKeyPreview by viewModel.localKeyPreview.collectAsStateWithLifecycle()
    val clipboardManager = LocalClipboardManager.current

    val settings = (settingsState as? UiState.Success)?.data ?: UserSettings()

    var displayName by remember { mutableStateOf(settings.displayName) }
    var customInstructions by remember { mutableStateOf(settings.customInstructions) }
    var temperature by remember { mutableStateOf(settings.temperature.toFloat()) }
    var maxTokens by remember { mutableStateOf(settings.maxTokens.toFloat()) }
    var apiKeyInput by remember { mutableStateOf("") }
    var showModelSheet by remember { mutableStateOf(false) }

    LaunchedEffect(settings.updatedAt, settings.displayName, settings.customInstructions) {
        displayName = settings.displayName
        customInstructions = settings.customInstructions
        temperature = settings.temperature.toFloat()
        maxTokens = settings.maxTokens.toFloat()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .widthIn(max = 820.dp)
                .fillMaxSize()
        ) {
            item {
                Text(
                    text = "MirzaAi Studio & Cloud Sync",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            // Account & Real-Time Cloud Sync Status Card
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    tonalElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = settings.displayName.take(1).uppercase().ifBlank { "M" },
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = settings.displayName,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = userEmail.ifBlank { "Signed in via Google" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.CloudDone,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = "Firebase Firestore Real-Time Sync Active",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = onSignOut,
                            modifier = Modifier.testTag("sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.Logout,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.sign_out))
                        }
                    }
                }
            }

            // OpenRouter API Key (Device Local)
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.Key,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "OpenRouter API Key (Device Local)",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Surface(
                                color = if (hasApiKey) {
                                    MaterialTheme.colorScheme.secondaryContainer
                                } else {
                                    MaterialTheme.colorScheme.errorContainer
                                },
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (hasApiKey) "Active" else "Not Configured",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (hasApiKey) {
                                        MaterialTheme.colorScheme.onSecondaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onErrorContainer
                                    },
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = if (localKeyPreview.isNotBlank()) {
                                "Saved locally on this device: $localKeyPreview (never synced to Firestore)."
                            } else {
                                "Paste your personal OpenRouter key here. Stored only on this device and never uploaded to cloud sync."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = { apiKeyInput = it },
                            label = { Text("OpenRouter Key (sk-or-v1-...)") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_api_key_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val clip = clipboardManager.getText()?.text?.trim().orEmpty()
                                    if (clip.isNotBlank()) {
                                        apiKeyInput = clip
                                    }
                                },
                                modifier = Modifier.testTag("settings_paste_key_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ContentPaste,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("Paste")
                            }

                            Button(
                                onClick = {
                                    viewModel.saveLocalApiKey(apiKeyInput)
                                    apiKeyInput = ""
                                },
                                enabled = apiKeyInput.isNotBlank(),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_save_key_button")
                            ) {
                                Text("Save Key")
                            }

                            if (localKeyPreview.isNotBlank()) {
                                TextButton(
                                    onClick = {
                                        viewModel.clearLocalApiKey()
                                        apiKeyInput = ""
                                    },
                                    modifier = Modifier.testTag("settings_clear_key_button")
                                ) {
                                    Text("Clear")
                                }
                            }
                        }
                    }
                }
            }

            // Appearance & Language
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Interface Theme", style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemeMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = ThemeMode.fromRaw(settings.themeMode) == mode,
                                    onClick = { viewModel.saveSettings(settings.copy(themeMode = mode.name)) },
                                    label = { Text(mode.label) }
                                )
                            }
                        }

                        Text("Response Language", style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ResponseLanguage.entries.forEach { lang ->
                                FilterChip(
                                    selected = ResponseLanguage.fromRaw(settings.responseLanguage) == lang,
                                    onClick = { viewModel.saveSettings(settings.copy(responseLanguage = lang.name)) },
                                    label = { Text(lang.label) }
                                )
                            }
                        }
                    }
                }
            }

            // Default OpenRouter Model & Custom Instructions
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Default OpenRouter Model", style = MaterialTheme.typography.titleMedium)
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showModelSheet = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    val modelObj = allModels.firstOrNull { it.id == settings.preferredModelId }
                                    Text(
                                        text = modelObj?.name ?: settings.preferredModelId,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = settings.preferredModelId,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = "Pick default model")
                            }
                        }

                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it },
                            label = { Text("Studio Display Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = customInstructions,
                            onValueChange = { customInstructions = it },
                            label = { Text("Global Custom Instructions (System Persona)") },
                            placeholder = { Text("e.g., Always include confidence intervals and executive bullet points…") },
                            minLines = 3,
                            maxLines = 6,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Column {
                            Text("Default Temperature: ${(temperature * 100).roundToInt() / 100.0}")
                            Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0f..1.5f)
                        }

                        Column {
                            Text("Default Max Tokens: ${maxTokens.roundToInt()}")
                            Slider(value = maxTokens, onValueChange = { maxTokens = it }, valueRange = 512f..16384f)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Real-time Streaming Responses")
                            Switch(
                                checked = settings.streamingEnabled,
                                onCheckedChange = { viewModel.saveSettings(settings.copy(streamingEnabled = it)) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Show Reasoning / Thinking Trace")
                            Switch(
                                checked = settings.showReasoning,
                                onCheckedChange = { viewModel.saveSettings(settings.copy(showReasoning = it)) }
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.saveSettings(
                                    settings.copy(
                                        displayName = displayName,
                                        customInstructions = customInstructions,
                                        temperature = (temperature * 100).roundToInt() / 100.0,
                                        maxTokens = maxTokens.roundToInt().toLong()
                                    )
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_settings_button")
                        ) {
                            Text("Save & Sync Preferences")
                        }
                    }
                }
            }
        }
    }

    if (showModelSheet) {
        ModelPickerSheet(
            models = allModels,
            selectedModelId = settings.preferredModelId,
            isLoading = isLoadingModels,
            onRefresh = { viewModel.refreshOpenRouterModels() },
            onSelectModel = { model ->
                viewModel.saveSettings(settings.copy(preferredModelId = model.id))
                viewModel.selectModel(model.id)
            },
            onDismiss = { showModelSheet = false }
        )
    }
}
