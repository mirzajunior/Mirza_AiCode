package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Editorial Claude-Inspired Palette
val TerracottaPrimary = Color(0xFFD97757)
val TerracottaDark = Color(0xFFB55436)
val TerracottaLight = Color(0xFFE89578)
val TerracottaContainerLight = Color(0xFFFBE7DF)
val TerracottaContainerDark = Color(0xFF4B251A)

val SageSecondary = Color(0xFF2A6F68)
val SageLight = Color(0xFF53A89F)
val SageContainerLight = Color(0xFFD9F0ED)
val SageContainerDark = Color(0xFF183D39)

val AmberTertiary = Color(0xFFC2812D)
val AmberLight = Color(0xFFE8B064)
val AmberContainerLight = Color(0xFFF9ECD7)
val AmberContainerDark = Color(0xFF452E10)

// Light Surface Tokens (Warm Alabaster / Parchment)
val AlabasterBackground = Color(0xFFFAF8F5)
val WarmPaperSurface = Color(0xFFFFFFFF)
val WarmStoneSurfaceVariant = Color(0xFFF2ECE4)
val WarmSurfaceContainer = Color(0xFFF5F1EB)
val WarmSurfaceContainerHigh = Color(0xFFECE5DC)
val WarmOutlineLight = Color(0xFFDCD3C8)
val CharcoalInk = Color(0xFF1C1917)
val WarmSlateInk = Color(0xFF5E5851)

// Dark Surface Tokens (Obsidian Studio)
val ObsidianBackground = Color(0xFF141312)
val ObsidianSurface = Color(0xFF1E1C1A)
val ObsidianSurfaceVariant = Color(0xFF2A2724)
val ObsidianSurfaceContainer = Color(0xFF23201E)
val ObsidianSurfaceContainerHigh = Color(0xFF2E2A27)
val ObsidianOutlineDark = Color(0xFF413C37)
val CreamInk = Color(0xFFF5F2ED)
val WarmAshInk = Color(0xFFB5ADA4)

// Semantic Status Colors
val ErrorCrimsonLight = Color(0xFFB3261E)
val ErrorCrimsonDark = Color(0xFFF2B8B5)
val CodeBlockBgLight = Color(0xFF1D1B19)
val CodeBlockBgDark = Color(0xFF11100F)
