package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AiSkill
import com.example.data.model.SkillCategory
import com.example.data.model.UiState
import com.example.data.plugins.DefaultSkills
import com.example.ui.viewmodel.MirzaViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkillsWorkflowsScreen(
    viewModel: MirzaViewModel,
    onRunWorkflowInChat: (AiSkill, String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val skillsState by viewModel.skillsState.collectAsStateWithLifecycle()
    val allModels by viewModel.allModels.collectAsStateWithLifecycle()

    var editingSkill by remember { mutableStateOf<AiSkill?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }
    var workflowRunTarget by remember { mutableStateOf<AiSkill?>(null) }
    var workflowRunInput by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingSkill = null
                    showEditorDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("create_skill_fab")
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Create custom skill")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .widthIn(max = 820.dp)
                    .fillMaxSize()
            ) {
                item {
                    Column {
                        Text(
                            text = "Skills & Automated Workflows",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Install custom AI personas, slash commands, and multi-step automated pipelines synced across all your devices.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                when (val state = skillsState) {
                    UiState.Loading -> {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator()
                            }
                        }
                    }
                    is UiState.Error -> {
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = state.message,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }
                    is UiState.Success -> {
                        val userSkills = state.data
                        item {
                            StarterTemplatesBanner(
                                hasExisting = userSkills.isNotEmpty(),
                                onInstallAll = { viewModel.installAllStarterSkills() },
                                onInstallTemplate = { tmpl -> viewModel.installStarterSkill(tmpl) }
                            )
                        }

                        if (userSkills.isEmpty()) {
                            item {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.AutoAwesome,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Spacer(Modifier.height(10.dp))
                                        Text(
                                            text = "No Custom Skills Yet",
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            text = "Tap + to build your own automated workflow or install our Data Scientist & Research starter templates above.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        } else {
                            items(userSkills, key = { it.id }) { skill ->
                                SkillCard(
                                    skill = skill,
                                    onToggleEnabled = { viewModel.toggleSkillEnabled(skill) },
                                    onEdit = {
                                        editingSkill = skill
                                        showEditorDialog = true
                                    },
                                    onDelete = { viewModel.deleteSkill(skill.id) },
                                    onRun = {
                                        workflowRunTarget = skill
                                        workflowRunInput = ""
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        SkillEditorDialog(
            initialSkill = editingSkill,
            availablePlugins = viewModel.pluginEngine.availablePlugins.map { it.id to it.name },
            availableModels = allModels.take(30).map { it.id to it.name },
            onSave = { updated ->
                viewModel.saveSkill(updated)
                showEditorDialog = false
            },
            onDismiss = { showEditorDialog = false }
        )
    }

    workflowRunTarget?.let { targetSkill ->
        AlertDialog(
            onDismissRequest = { workflowRunTarget = null },
            title = { Text("Run '${targetSkill.name}'") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (targetSkill.workflowSteps.isNotEmpty()) {
                            "Executes ${targetSkill.workflowSteps.size} automated steps sequentially with synced plugins."
                        } else {
                            "Starts a chat session pre-configured with ${targetSkill.slashCommand}."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = workflowRunInput,
                        onValueChange = { workflowRunInput = it },
                        label = { Text("Input data, topic, or prompt") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val prompt = workflowRunInput
                    workflowRunTarget = null
                    onRunWorkflowInChat(targetSkill, prompt)
                }) {
                    Text("Run Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { workflowRunTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun StarterTemplatesBanner(
    hasExisting: Boolean,
    onInstallAll: () -> Unit,
    onInstallTemplate: (AiSkill) -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Pro Skill & Workflow Templates",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "1-tap install ready-made Data, Research & Architect pipelines",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (!hasExisting) {
                    Button(
                        onClick = onInstallAll,
                        modifier = Modifier.testTag("install_starter_skills_button")
                    ) {
                        Text("Install All")
                    }
                } else {
                    OutlinedButton(onClick = onInstallAll) {
                        Text("Sync All")
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DefaultSkills.starterTemplates.forEach { tmpl ->
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInstallTemplate(tmpl) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${tmpl.name} (${tmpl.slashCommand})",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = tmpl.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "+ Add",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SkillCard(
    skill: AiSkill,
    onToggleEnabled: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRun: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = skill.name,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = skill.slashCommand,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (skill.description.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = skill.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = skill.enabled,
                    onCheckedChange = { onToggleEnabled() }
                )
            }

            if (skill.workflowSteps.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Route,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "Automated Workflow (${skill.workflowSteps.size} Steps)",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        skill.workflowSteps.forEachIndexed { idx, step ->
                            Text(
                                text = "${idx + 1}. $step",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = SkillCategory.fromRaw(skill.category).label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                skill.attachedPluginIds.forEach { pluginId ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = pluginId,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit skill")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete skill")
                    }
                }
                Button(
                    onClick = onRun,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (skill.workflowSteps.isNotEmpty()) "Run Workflow" else "Use Skill")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SkillEditorDialog(
    initialSkill: AiSkill?,
    availablePlugins: List<Pair<String, String>>,
    availableModels: List<Pair<String, String>>,
    onSave: (AiSkill) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initialSkill?.name ?: "") }
    var slashCmd by remember { mutableStateOf(initialSkill?.slashCommand ?: "/custom") }
    var category by remember { mutableStateOf(SkillCategory.fromRaw(initialSkill?.category)) }
    var description by remember { mutableStateOf(initialSkill?.description ?: "") }
    var systemPrompt by remember { mutableStateOf(initialSkill?.systemPrompt ?: "") }
    var preferredModelId by remember { mutableStateOf(initialSkill?.preferredModelId ?: "") }
    var temperature by remember { mutableStateOf((initialSkill?.temperature ?: 0.3).toFloat()) }
    val selectedPlugins = remember {
        mutableStateListOf<String>().apply {
            addAll(initialSkill?.attachedPluginIds ?: listOf("data_analyzer"))
        }
    }
    val workflowSteps = remember {
        mutableStateListOf<String>().apply {
            addAll(initialSkill?.workflowSteps.orEmpty())
        }
    }
    var newStepDraft by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialSkill == null) "Create Custom Skill & Workflow" else "Edit Skill") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Skill Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = slashCmd,
                    onValueChange = { slashCmd = it },
                    label = { Text("Slash Trigger (e.g. /audit)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Category", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SkillCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Short Description") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = { systemPrompt = it },
                    label = { Text("System Instructions / Persona") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Preferred Model (Optional)", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = preferredModelId.isBlank(),
                        onClick = { preferredModelId = "" },
                        label = { Text("Use Active") }
                    )
                    availableModels.take(6).forEach { (id, label) ->
                        FilterChip(
                            selected = preferredModelId == id,
                            onClick = { preferredModelId = id },
                            label = { Text(label.take(20)) }
                        )
                    }
                }

                Column {
                    Text("Temperature: ${(temperature * 100).roundToInt() / 100.0}", style = MaterialTheme.typography.labelLarge)
                    Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0f..1.5f)
                }

                Text("Auto-Attach Plugins", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    availablePlugins.forEach { (id, label) ->
                        val checked = id in selectedPlugins
                        FilterChip(
                            selected = checked,
                            onClick = {
                                if (checked) selectedPlugins.remove(id) else selectedPlugins.add(id)
                            },
                            label = { Text(label.substringBefore(" ")) }
                        )
                    }
                }

                Text("Automated Multi-Step Workflow (Optional)", style = MaterialTheme.typography.labelLarge)
                workflowSteps.forEachIndexed { idx, step ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${idx + 1}. $step",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { workflowSteps.removeAt(idx) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Remove step", modifier = Modifier.size(16.dp))
                        }
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = newStepDraft,
                        onValueChange = { newStepDraft = it },
                        label = { Text("Add workflow step") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = {
                            if (newStepDraft.isNotBlank() && workflowSteps.size < 10) {
                                workflowSteps.add(newStepDraft.trim())
                                newStepDraft = ""
                            }
                        }
                    ) {
                        Text("+Step")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val base = initialSkill ?: AiSkill()
                    onSave(
                        base.copy(
                            name = name.ifBlank { "Custom Skill" },
                            slashCommand = slashCmd.ifBlank { "/custom" },
                            category = category.name,
                            description = description,
                            systemPrompt = systemPrompt.ifBlank { "Analyze carefully and concisely." },
                            preferredModelId = preferredModelId,
                            temperature = ((temperature * 100).roundToInt() / 100.0),
                            workflowSteps = workflowSteps.toList(),
                            attachedPluginIds = selectedPlugins.toList(),
                            enabled = true
                        )
                    )
                }
            ) {
                Text("Save to Cloud")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
