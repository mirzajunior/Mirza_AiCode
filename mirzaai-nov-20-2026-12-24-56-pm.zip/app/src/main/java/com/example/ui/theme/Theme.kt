package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.ThemeMode

private val LightColorScheme = lightColorScheme(
    primary = TerracottaPrimary,
    onPrimary = Color.White,
    primaryContainer = TerracottaContainerLight,
    onPrimaryContainer = TerracottaDark,
    secondary = SageSecondary,
    onSecondary = Color.White,
    secondaryContainer = SageContainerLight,
    onSecondaryContainer = SageSecondary,
    tertiary = AmberTertiary,
    onTertiary = Color.White,
    tertiaryContainer = AmberContainerLight,
    onTertiaryContainer = Color(0xFF4E3108),
    background = AlabasterBackground,
    onBackground = CharcoalInk,
    surface = WarmPaperSurface,
    onSurface = CharcoalInk,
    surfaceVariant = WarmStoneSurfaceVariant,
    onSurfaceVariant = WarmSlateInk,
    surfaceContainerLowest = WarmPaperSurface,
    surfaceContainerLow = AlabasterBackground,
    surfaceContainer = WarmSurfaceContainer,
    surfaceContainerHigh = WarmSurfaceContainerHigh,
    surfaceContainerHighest = WarmStoneSurfaceVariant,
    outline = WarmOutlineLight,
    outlineVariant = Color(0xFFE8E0D6),
    error = ErrorCrimsonLight,
    onError = Color.White,
)

private val DarkColorScheme = darkColorScheme(
    primary = TerracottaLight,
    onPrimary = Color(0xFF2D120A),
    primaryContainer = TerracottaContainerDark,
    onPrimaryContainer = Color(0xFFFFDBD0),
    secondary = SageLight,
    onSecondary = Color(0xFF0A2421),
    secondaryContainer = SageContainerDark,
    onSecondaryContainer = Color(0xFFC2ECE7),
    tertiary = AmberLight,
    onTertiary = Color(0xFF2D1C05),
    tertiaryContainer = AmberContainerDark,
    onTertiaryContainer = Color(0xFFFFE0B2),
    background = ObsidianBackground,
    onBackground = CreamInk,
    surface = ObsidianSurface,
    onSurface = CreamInk,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = WarmAshInk,
    surfaceContainerLowest = Color(0xFF11100F),
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceContainer,
    surfaceContainerHigh = ObsidianSurfaceContainerHigh,
    surfaceContainerHighest = Color(0xFF37332F),
    outline = ObsidianOutlineDark,
    outlineVariant = Color(0xFF332F2B),
    error = ErrorCrimsonDark,
    onError = Color(0xFF601410),
)

val MirzaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun MirzaAiTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit,
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (isDark) DarkColorScheme else LightColorScheme,
        typography = MirzaTypography,
        shapes = MirzaShapes,
        content = content
    )
}
