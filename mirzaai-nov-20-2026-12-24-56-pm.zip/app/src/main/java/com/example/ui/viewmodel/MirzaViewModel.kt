package com.example.ui.viewmodel

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.MirzaCloudRepository
import com.example.data.model.AiSkill
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.OpenRouterModel
import com.example.data.model.PendingAttachment
import com.example.data.model.PluginExecutionResult
import com.example.data.model.ResponseLanguage
import com.example.data.model.UiState
import com.example.data.model.UserSettings
import com.example.data.model.WorkflowProgress
import com.example.data.model.WorkspaceMemory
import com.example.data.plugins.DefaultSkills
import com.example.data.plugins.MirzaPluginEngine
import com.example.data.remote.OpenRouterCatalog
import com.example.data.remote.OpenRouterClient
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class MirzaViewModel(
    private val cloudRepository: MirzaCloudRepository,
    private val openRouterClient: OpenRouterClient,
    val pluginEngine: MirzaPluginEngine,
    private val currentUserId: String,
    private val initialDisplayName: String,
    private val localPrefs: SharedPreferences? = null,
) : ViewModel() {

    private companion object {
        const val TAG = "MirzaVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
        const val MAX_TOOL_ROUNDS = 4
        const val PREF_LOCAL_OPENROUTER_KEY = "local_openrouter_api_key"
    }

    // --- REAL-TIME CLOUD STREAMS (Two-Tier Error Unwrapping) ---

    val settingsState: StateFlow<UiState<UserSettings>> = cloudRepository.observeSettings(currentUserId)
        .map<UserSettings?, UiState<UserSettings>> { settings ->
            UiState.Success(settings ?: UserSettings(userId = currentUserId, displayName = initialDisplayName))
        }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing settings", root)
            emit(UiState.Error(root.message ?: "Failed to sync settings"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    val conversationsState: StateFlow<UiState<List<Conversation>>> =
        cloudRepository.observeConversations(currentUserId)
            .map<List<Conversation>, UiState<List<Conversation>>> { UiState.Success(it) }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                Log.w(TAG, "Error observing conversations", root)
                emit(UiState.Error(root.message ?: "Failed to sync conversations"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    val skillsState: StateFlow<UiState<List<AiSkill>>> =
        cloudRepository.observeSkills(currentUserId)
            .map<List<AiSkill>, UiState<List<AiSkill>>> { UiState.Success(it) }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                Log.w(TAG, "Error observing skills", root)
                emit(UiState.Error(root.message ?: "Failed to sync skills"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    val memoriesState: StateFlow<UiState<List<WorkspaceMemory>>> =
        cloudRepository.observeMemories(currentUserId)
            .map<List<WorkspaceMemory>, UiState<List<WorkspaceMemory>>> { UiState.Success(it) }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                Log.w(TAG, "Error observing memories", root)
                emit(UiState.Error(root.message ?: "Failed to sync memories"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    val messagesState: StateFlow<UiState<List<ChatMessage>>> = _activeConversationId
        .flatMapLatest { convId ->
            if (convId.isNullOrBlank()) {
                flowOf<UiState<List<ChatMessage>>>(UiState.Success(emptyList()))
            } else {
                cloudRepository.observeMessages(currentUserId, convId)
                    .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
                    .catch { error ->
                        val root = unwrapFirestoreError(error)
                        Log.w(TAG, "Error observing messages", root)
                        emit(UiState.Error(root.message ?: "Failed to sync messages"))
                    }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Success(emptyList()))

    // --- OPENROUTER MODELS ---

    private val _allModels = MutableStateFlow(OpenRouterCatalog.fallbackModels)
    val allModels: StateFlow<List<OpenRouterModel>> = _allModels.asStateFlow()

    private val _isLoadingModels = MutableStateFlow(false)
    val isLoadingModels: StateFlow<Boolean> = _isLoadingModels.asStateFlow()

    private val _selectedModelId = MutableStateFlow("anthropic/claude-3.7-sonnet")
    val selectedModelId: StateFlow<String> = _selectedModelId.asStateFlow()

    // --- CHAT & WORKFLOW RUNTIME STATE ---

    private val _selectedSkillId = MutableStateFlow<String?>(null)
    val selectedSkillId: StateFlow<String?> = _selectedSkillId.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingContent = MutableStateFlow("")
    val streamingContent: StateFlow<String> = _streamingContent.asStateFlow()

    private val _streamingReasoning = MutableStateFlow("")
    val streamingReasoning: StateFlow<String> = _streamingReasoning.asStateFlow()

    private val _streamingPluginLog = MutableStateFlow("")
    val streamingPluginLog: StateFlow<String> = _streamingPluginLog.asStateFlow()

    private val _workflowProgress = MutableStateFlow<WorkflowProgress?>(null)
    val workflowProgress: StateFlow<WorkflowProgress?> = _workflowProgress.asStateFlow()

    private val _pendingAttachments = MutableStateFlow<List<PendingAttachment>>(emptyList())
    val pendingAttachments: StateFlow<List<PendingAttachment>> = _pendingAttachments.asStateFlow()

    private val _sandboxResult = MutableStateFlow<PluginExecutionResult?>(null)
    val sandboxResult: StateFlow<PluginExecutionResult?> = _sandboxResult.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _hasApiKeyState = MutableStateFlow(openRouterClient.hasValidApiKey())
    val hasApiKeyState: StateFlow<Boolean> = _hasApiKeyState.asStateFlow()

    private val _localKeyPreview = MutableStateFlow(maskKey(localPrefs?.getString(PREF_LOCAL_OPENROUTER_KEY, "").orEmpty()))
    val localKeyPreview: StateFlow<String> = _localKeyPreview.asStateFlow()

    val hasApiKey: Boolean get() = openRouterClient.hasValidApiKey()

    fun saveLocalApiKey(rawKey: String) {
        val cleaned = rawKey.trim()
        if (cleaned.isBlank()) {
            _statusBanner.value = "API key cannot be empty."
            return
        }
        localPrefs?.edit()?.putString(PREF_LOCAL_OPENROUTER_KEY, cleaned)?.apply()
        _hasApiKeyState.value = openRouterClient.hasValidApiKey()
        _localKeyPreview.value = maskKey(cleaned)
        _statusBanner.value = "OpenRouter API key saved on this device."
        refreshOpenRouterModels()
    }

    fun clearLocalApiKey() {
        localPrefs?.edit()?.remove(PREF_LOCAL_OPENROUTER_KEY)?.apply()
        _hasApiKeyState.value = openRouterClient.hasValidApiKey()
        _localKeyPreview.value = ""
        _statusBanner.value = "Local OpenRouter API key cleared."
    }

    private fun maskKey(key: String): String {
        val k = key.trim()
        if (k.isBlank()) return ""
        return if (k.length <= 14) "••••••" else "${k.take(10)}••••${k.takeLast(4)}"
    }

    init {
        viewModelScope.launch {
            cloudRepository.ensureUserSettings(currentUserId, initialDisplayName)
        }
        viewModelScope.launch {
            settingsState.collect { state ->
                if (state is UiState.Success && _activeConversationId.value == null) {
                    _selectedModelId.value = state.data.preferredModelId
                }
            }
        }
        refreshOpenRouterModels()
    }

    private fun unwrapFirestoreError(error: Throwable): Throwable {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        return firestoreError ?: error
    }

    fun dismissStatusBanner() {
        _statusBanner.value = null
    }

    fun refreshOpenRouterModels() {
        if (_isLoadingModels.value) return
        viewModelScope.launch {
            _isLoadingModels.value = true
            val result = openRouterClient.fetchAllModels()
            result.onSuccess { list ->
                _allModels.value = list
            }.onFailure { err ->
                Log.w(TAG, "Failed to fetch live OpenRouter models, using curated fallback: ${err.message}")
            }
            _isLoadingModels.value = false
        }
    }

    fun selectModel(modelId: String) {
        _selectedModelId.value = modelId
        val convId = _activeConversationId.value
        if (!convId.isNullOrBlank()) {
            viewModelScope.launch {
                cloudRepository.updateConversationMetadata(currentUserId, convId, modelId = modelId)
            }
        }
    }

    fun selectSkill(skillId: String?) {
        _selectedSkillId.value = skillId
        val skill = (skillsState.value as? UiState.Success)?.data?.firstOrNull { it.id == skillId }
        if (skill != null && skill.preferredModelId.isNotBlank()) {
            _selectedModelId.value = skill.preferredModelId
        }
    }

    fun startNewConversation() {
        _activeConversationId.value = null
        _streamingContent.value = ""
        _streamingReasoning.value = ""
        _streamingPluginLog.value = ""
        _pendingAttachments.value = emptyList()
    }

    fun openConversation(conversation: Conversation) {
        _activeConversationId.value = conversation.id
        if (conversation.modelId.isNotBlank()) {
            _selectedModelId.value = conversation.modelId
        }
        _selectedSkillId.value = conversation.activeSkillId.ifBlank { null }
    }

    fun togglePinConversation(conversation: Conversation) {
        viewModelScope.launch {
            cloudRepository.updateConversationMetadata(
                userId = currentUserId,
                conversationId = conversation.id,
                pinned = !conversation.pinned
            )
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            if (_activeConversationId.value == conversationId) {
                _activeConversationId.value = null
            }
            cloudRepository.deleteConversation(currentUserId, conversationId)
        }
    }

    // --- ATTACHMENTS (Zero-permission SAF & Photo Picker) ---

    fun attachFileFromUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            val att = withContext(Dispatchers.IO) {
                readUriAttachment(context, uri)
            }
            if (att != null) {
                _pendingAttachments.value = _pendingAttachments.value + att
            } else {
                _statusBanner.value = "Could not read selected file."
            }
        }
    }

    fun removeAttachment(id: String) {
        _pendingAttachments.value = _pendingAttachments.value.filterNot { it.id == id }
    }

    private fun readUriAttachment(context: Context, uri: Uri): PendingAttachment? {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        var fileName = "attachment"
        var size = 0L
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
            }
        }

        val isImg = mime.startsWith("image/") || fileName.endsWith(".png", true) ||
            fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true) || fileName.endsWith(".webp", true)

        return if (isImg) {
            val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val maxDim = 1024
            val scaled = if (bitmap.width > maxDim || bitmap.height > maxDim) {
                val ratio = minOf(maxDim.toFloat() / bitmap.width, maxDim.toFloat() / bitmap.height)
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * ratio).toInt().coerceAtLeast(1),
                    (bitmap.height * ratio).toInt().coerceAtLeast(1),
                    true
                )
            } else bitmap
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            PendingAttachment(
                id = UUID.randomUUID().toString(),
                fileName = fileName,
                mimeType = "image/jpeg",
                isImage = true,
                imageBase64DataUrl = "data:image/jpeg;base64,$b64",
                sizeBytes = size
            )
        } else {
            val text = resolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                val buffer = CharArray(32_000)
                val read = reader.read(buffer)
                if (read > 0) String(buffer, 0, read) else ""
            }.orEmpty()
            val profile = if (fileName.endsWith(".csv", true) || fileName.endsWith(".tsv", true) || fileName.endsWith(".json", true)) {
                val res = pluginEngine.runDataAnalyzer(text)
                if (res.success) res.output else ""
            } else ""
            PendingAttachment(
                id = UUID.randomUUID().toString(),
                fileName = fileName,
                mimeType = mime,
                isImage = false,
                textContent = text,
                sizeBytes = size,
                localDataProfile = profile
            )
        }
    }

    // --- SEND MESSAGE & AUTOMATED WORKFLOW EXECUTION ---

    fun sendMessage(rawPrompt: String) {
        val prompt = rawPrompt.trim()
        val attachments = _pendingAttachments.value
        if ((prompt.isBlank() && attachments.isEmpty()) || _isGenerating.value) return

        viewModelScope.launch {
            _isGenerating.value = true
            _streamingContent.value = ""
            _streamingReasoning.value = ""
            _streamingPluginLog.value = ""

            try {
                val settings = (settingsState.value as? UiState.Success)?.data
                    ?: UserSettings(userId = currentUserId, displayName = initialDisplayName)
                val skillsList = (skillsState.value as? UiState.Success)?.data.orEmpty()
                val memoriesList = (memoriesState.value as? UiState.Success)?.data.orEmpty()

                // Detect /slash command invocation if user typed one
                val matchedSlashSkill = if (prompt.startsWith("/")) {
                    val cmd = prompt.substringBefore(" ").trim()
                    skillsList.firstOrNull { it.enabled && it.slashCommand.equals(cmd, ignoreCase = true) }
                } else null

                val activeSkill = matchedSlashSkill
                    ?: skillsList.firstOrNull { it.id == _selectedSkillId.value && it.enabled }

                val modelId = activeSkill?.preferredModelId?.takeIf { it.isNotBlank() }
                    ?: _selectedModelId.value.ifBlank { settings.preferredModelId }

                var convId = _activeConversationId.value
                val currentMessages = (messagesState.value as? UiState.Success)?.data.orEmpty()
                if (convId.isNullOrBlank()) {
                    val titleCandidate = prompt.ifBlank { attachments.firstOrNull()?.fileName ?: "Data Analysis" }
                        .take(54)
                    val created = cloudRepository.createConversation(
                        userId = currentUserId,
                        title = titleCandidate,
                        modelId = modelId,
                        activeSkillId = activeSkill?.id.orEmpty()
                    )
                    convId = created.getOrElse { err ->
                        _statusBanner.value = "Cloud sync error: ${err.message}"
                        return@launch
                    }
                    _activeConversationId.value = convId
                }

                val attSummary = attachments.joinToString(", ") { it.fileName }.take(450)
                cloudRepository.addMessage(
                    userId = currentUserId,
                    conversationId = convId,
                    role = "user",
                    content = prompt.ifBlank { "Analyze attached data: $attSummary" },
                    modelId = modelId,
                    skillName = activeSkill?.name.orEmpty(),
                    attachmentSummary = attSummary
                )

                val enabledPlugins = (settings.enabledPluginIds + (activeSkill?.attachedPluginIds.orEmpty())).distinct()
                val modelMeta = _allModels.value.firstOrNull { it.id == modelId }
                val allowTools = (modelMeta?.supportsTools ?: true) && enabledPlugins.isNotEmpty()
                val temperature = activeSkill?.temperature ?: settings.temperature

                // Clear pending attachments immediately after capture
                _pendingAttachments.value = emptyList()

                val systemPrompt = buildSystemPrompt(settings, activeSkill, memoriesList, enabledPlugins)
                val attachmentTextContext = buildAttachmentTextContext(attachments)
                val imageUrls = attachments.filter { it.isImage }.map { it.imageBase64DataUrl }

                if (activeSkill != null && activeSkill.workflowSteps.isNotEmpty()) {
                    executeAutomatedWorkflow(
                        convId = convId,
                        userPrompt = prompt,
                        attachmentTextContext = attachmentTextContext,
                        imageUrls = imageUrls,
                        systemPrompt = systemPrompt,
                        skill = activeSkill,
                        modelId = modelId,
                        temperature = temperature,
                        maxTokens = settings.maxTokens.toInt(),
                        stream = settings.streamingEnabled,
                        enabledPlugins = enabledPlugins,
                        allowTools = allowTools,
                        priorCount = currentMessages.size + 1L
                    )
                } else {
                    executeSingleConversationTurn(
                        convId = convId,
                        priorHistory = currentMessages,
                        userPrompt = prompt,
                        attachmentTextContext = attachmentTextContext,
                        imageUrls = imageUrls,
                        systemPrompt = systemPrompt,
                        skillName = activeSkill?.name.orEmpty(),
                        modelId = modelId,
                        temperature = temperature,
                        maxTokens = settings.maxTokens.toInt(),
                        stream = settings.streamingEnabled,
                        enabledPlugins = enabledPlugins,
                        allowTools = allowTools,
                        priorCount = currentMessages.size + 1L
                    )
                }
            } finally {
                _isGenerating.value = false
                _workflowProgress.value = null
            }
        }
    }

    private suspend fun executeSingleConversationTurn(
        convId: String,
        priorHistory: List<ChatMessage>,
        userPrompt: String,
        attachmentTextContext: String,
        imageUrls: List<String>,
        systemPrompt: String,
        skillName: String,
        modelId: String,
        temperature: Double,
        maxTokens: Int,
        stream: Boolean,
        enabledPlugins: List<String>,
        allowTools: Boolean,
        priorCount: Long,
    ) {
        val messagesJson = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            priorHistory.takeLast(14).forEach { msg ->
                if (msg.role == "user" || msg.role == "assistant") {
                    put(JSONObject().put("role", msg.role).put("content", msg.content.take(12000)))
                }
            }
            put(buildUserMessageJson(userPrompt + attachmentTextContext, imageUrls))
        }

        val toolsJson = if (allowTools) pluginEngine.buildToolsJson(enabledPlugins) else null
        val pluginLogs = mutableListOf<String>()
        val combinedReasoning = StringBuilder()
        var finalContent = ""

        for (round in 0 until MAX_TOOL_ROUNDS) {
            _streamingContent.value = ""
            val result = openRouterClient.sendChatCompletion(
                modelId = modelId,
                messagesJson = messagesJson,
                toolsJson = toolsJson,
                temperature = temperature,
                maxTokens = maxTokens,
                stream = stream,
                onStreamDelta = { cDelta, rDelta ->
                    if (cDelta.isNotEmpty()) _streamingContent.value += cDelta
                    if (rDelta.isNotEmpty()) _streamingReasoning.value += rDelta
                }
            )

            val turn = result.getOrElse { err ->
                val errorText = "MirzaAi could not complete the request: ${err.message}"
                _statusBanner.value = errorText
                cloudRepository.addMessage(
                    userId = currentUserId,
                    conversationId = convId,
                    role = "assistant",
                    content = errorText,
                    modelId = modelId,
                    skillName = skillName
                )
                return
            }

            if (turn.reasoning.isNotBlank()) {
                if (combinedReasoning.isNotEmpty()) combinedReasoning.append("\n---\n")
                combinedReasoning.append(turn.reasoning)
            }

            if (turn.toolCalls.isEmpty()) {
                finalContent = turn.content.ifBlank { "(Model returned an empty response)" }
                break
            }

            // Append assistant tool-call message
            val assistantMsg = JSONObject().apply {
                put("role", "assistant")
                put("content", turn.content.ifBlank { JSONObject.NULL })
                val tcArr = JSONArray()
                turn.toolCalls.forEach { tc ->
                    tcArr.put(
                        JSONObject().apply {
                            put("id", tc.id)
                            put("type", "function")
                            put(
                                "function",
                                JSONObject().put("name", tc.name).put("arguments", tc.argumentsJson)
                            )
                        }
                    )
                }
                put("tool_calls", tcArr)
            }
            messagesJson.put(assistantMsg)

            // Execute each plugin tool locally
            for (tc in turn.toolCalls) {
                val execResult = pluginEngine.executePlugin(tc.name, tc.argumentsJson, currentUserId)
                val logLine = "[${execResult.pluginName}] ${execResult.summary}"
                pluginLogs.add(logLine)
                _streamingPluginLog.value = pluginLogs.joinToString("\n")
                messagesJson.put(
                    JSONObject().apply {
                        put("role", "tool")
                        put("tool_call_id", tc.id)
                        put("name", tc.name)
                        put("content", execResult.output)
                    }
                )
            }
        }

        val logText = pluginLogs.joinToString("\n")
        cloudRepository.addMessage(
            userId = currentUserId,
            conversationId = convId,
            role = "assistant",
            content = finalContent,
            reasoning = combinedReasoning.toString(),
            modelId = modelId,
            skillName = skillName,
            pluginLog = logText
        )
        cloudRepository.updateConversationMetadata(
            userId = currentUserId,
            conversationId = convId,
            modelId = modelId,
            activeSkillId = _selectedSkillId.value.orEmpty(),
            lastMessagePreview = finalContent.replace("\n", " ").take(260),
            messageCount = priorCount + 1L
        )
    }

    private suspend fun executeAutomatedWorkflow(
        convId: String,
        userPrompt: String,
        attachmentTextContext: String,
        imageUrls: List<String>,
        systemPrompt: String,
        skill: AiSkill,
        modelId: String,
        temperature: Double,
        maxTokens: Int,
        stream: Boolean,
        enabledPlugins: List<String>,
        allowTools: Boolean,
        priorCount: Long,
    ) {
        val steps = skill.workflowSteps
        val toolsJson = if (allowTools) pluginEngine.buildToolsJson(enabledPlugins) else null
        val stepOutputs = mutableListOf<String>()
        val allPluginLogs = mutableListOf<String>()
        val allReasoning = StringBuilder()

        steps.forEachIndexed { index, stepInstruction ->
            _workflowProgress.value = WorkflowProgress(
                skillName = skill.name,
                currentStepIndex = index + 1,
                totalSteps = steps.size,
                currentStepLabel = stepInstruction
            )
            _streamingContent.value = "Running workflow step ${index + 1}/${steps.size}: $stepInstruction\n\n"

            val stepPrompt = buildString {
                appendLine("Original User Request: $userPrompt")
                if (attachmentTextContext.isNotBlank()) appendLine(attachmentTextContext)
                if (stepOutputs.isNotEmpty()) {
                    appendLine("\nContext from previous workflow steps:")
                    stepOutputs.forEachIndexed { prevIdx, out ->
                        appendLine("--- Step ${prevIdx + 1} Output ---\n${out.take(4000)}")
                    }
                }
                appendLine("\nExecute Workflow Step ${index + 1} of ${steps.size}:")
                appendLine(stepInstruction)
            }

            val messagesJson = JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt))
                put(buildUserMessageJson(stepPrompt, if (index == 0) imageUrls else emptyList()))
            }

            var stepResultText = ""
            for (round in 0 until MAX_TOOL_ROUNDS) {
                val res = openRouterClient.sendChatCompletion(
                    modelId = modelId,
                    messagesJson = messagesJson,
                    toolsJson = toolsJson,
                    temperature = temperature,
                    maxTokens = maxTokens,
                    stream = stream,
                    onStreamDelta = { cDelta, rDelta ->
                        if (cDelta.isNotEmpty()) _streamingContent.value += cDelta
                        if (rDelta.isNotEmpty()) _streamingReasoning.value += rDelta
                    }
                )
                val turn = res.getOrElse { err ->
                    stepResultText = "Step ${index + 1} failed: ${err.message}"
                    break
                }
                if (turn.reasoning.isNotBlank()) {
                    allReasoning.append("Step ${index + 1}: ").appendLine(turn.reasoning)
                }
                if (turn.toolCalls.isEmpty()) {
                    stepResultText = turn.content
                    break
                }
                val assistantMsg = JSONObject().apply {
                    put("role", "assistant")
                    put("content", turn.content.ifBlank { JSONObject.NULL })
                    val tcArr = JSONArray()
                    turn.toolCalls.forEach { tc ->
                        tcArr.put(
                            JSONObject().put("id", tc.id).put("type", "function")
                                .put("function", JSONObject().put("name", tc.name).put("arguments", tc.argumentsJson))
                        )
                    }
                    put("tool_calls", tcArr)
                }
                messagesJson.put(assistantMsg)
                for (tc in turn.toolCalls) {
                    val exec = pluginEngine.executePlugin(tc.name, tc.argumentsJson, currentUserId)
                    allPluginLogs.add("Step ${index + 1} • [${exec.pluginName}] ${exec.summary}")
                    _streamingPluginLog.value = allPluginLogs.joinToString("\n")
                    messagesJson.put(
                        JSONObject().put("role", "tool").put("tool_call_id", tc.id)
                            .put("name", tc.name).put("content", exec.output)
                    )
                }
            }
            stepOutputs.add(stepResultText)
        }

        val combinedReport = buildString {
            appendLine("## Workflow Completed: ${skill.name}")
            stepOutputs.forEachIndexed { idx, output ->
                appendLine("\n### Step ${idx + 1}: ${steps[idx]}")
                appendLine(output)
            }
        }.trim()

        cloudRepository.addMessage(
            userId = currentUserId,
            conversationId = convId,
            role = "assistant",
            content = combinedReport,
            reasoning = allReasoning.toString(),
            modelId = modelId,
            skillName = skill.name,
            pluginLog = allPluginLogs.joinToString("\n")
        )
        cloudRepository.updateConversationMetadata(
            userId = currentUserId,
            conversationId = convId,
            modelId = modelId,
            activeSkillId = skill.id,
            lastMessagePreview = combinedReport.replace("\n", " ").take(260),
            messageCount = priorCount + 1L
        )
    }

    fun triggerWorkflowRun(skill: AiSkill, inputData: String) {
        selectSkill(skill.id)
        if (skill.preferredModelId.isNotBlank()) {
            _selectedModelId.value = skill.preferredModelId
        }
        startNewConversation()
        sendMessage(inputData.ifBlank { "Run workflow '${skill.name}'." })
    }

    private fun buildSystemPrompt(
        settings: UserSettings,
        activeSkill: AiSkill?,
        memories: List<WorkspaceMemory>,
        enabledPlugins: List<String>,
    ): String = buildString {
        appendLine("You are MirzaAi, an analytical, highly capable AI assistant inspired by Claude.")
        appendLine("Deliver structured, accurate, transparent analysis. Use markdown headings, bullet lists, and fenced code blocks cleanly.")
        val lang = ResponseLanguage.fromRaw(settings.responseLanguage)
        if (lang.instruction.isNotBlank()) appendLine(lang.instruction)
        if (settings.customInstructions.isNotBlank()) {
            appendLine("\nUser Custom Instructions:\n${settings.customInstructions}")
        }
        if (activeSkill != null) {
            appendLine("\nActive Custom Skill '${activeSkill.name}' (${activeSkill.slashCommand}):")
            appendLine(activeSkill.systemPrompt)
        }
        if (enabledPlugins.isNotEmpty()) {
            appendLine("\nEnabled Plugins: ${enabledPlugins.joinToString(", ")}. Use tool calls whenever exact computation, CSV/JSON statistical profiling, live URL fetching, regex/JSON checking, or cloud memory is needed.")
        }
        if (memories.isNotEmpty()) {
            appendLine("\nSynced Cloud Workspace Memory Context:")
            memories.take(8).forEach { mem ->
                appendLine("- [${mem.tag}] ${mem.title}: ${mem.content}")
            }
        }
    }

    private fun buildAttachmentTextContext(attachments: List<PendingAttachment>): String {
        val textParts = attachments.filter { !it.isImage }
        if (textParts.isEmpty()) return ""
        return buildString {
            appendLine("\n\n--- Attached Data Files ---")
            textParts.forEach { att ->
                appendLine("File: ${att.fileName} (${att.mimeType})")
                if (att.localDataProfile.isNotBlank()) {
                    appendLine("Pre-computed Local Data Profile:\n${att.localDataProfile}")
                }
                appendLine("Content:\n${att.textContent.take(15000)}")
            }
        }
    }

    private fun buildUserMessageJson(text: String, imageUrls: List<String>): JSONObject {
        if (imageUrls.isEmpty()) {
            return JSONObject().put("role", "user").put("content", text)
        }
        val contentArr = JSONArray().apply {
            put(JSONObject().put("type", "text").put("text", text.ifBlank { "Analyze the attached image(s)." }))
            imageUrls.forEach { dataUrl ->
                put(
                    JSONObject()
                        .put("type", "image_url")
                        .put("image_url", JSONObject().put("url", dataUrl))
                )
            }
        }
        return JSONObject().put("role", "user").put("content", contentArr)
    }

    // --- SKILLS, PLUGINS, MEMORIES & SETTINGS MUTATIONS ---

    fun saveSkill(skill: AiSkill) {
        viewModelScope.launch {
            val res = cloudRepository.upsertSkill(currentUserId, skill)
            _statusBanner.value = if (res.isSuccess) {
                "Skill '${skill.name}' synced to cloud."
            } else {
                "Failed to save skill: ${res.exceptionOrNull()?.message}"
            }
        }
    }

    fun installStarterSkill(template: AiSkill) {
        viewModelScope.launch {
            cloudRepository.upsertSkill(currentUserId, template.copy(id = "", userId = currentUserId))
            _statusBanner.value = "Installed '${template.name}' to your Cloud Skills."
        }
    }

    fun installAllStarterSkills() {
        viewModelScope.launch {
            val existingNames = (skillsState.value as? UiState.Success)?.data
                ?.map { it.name.lowercase() }?.toSet().orEmpty()
            var count = 0
            DefaultSkills.starterTemplates.forEach { tmpl ->
                if (tmpl.name.lowercase() !in existingNames) {
                    cloudRepository.upsertSkill(currentUserId, tmpl.copy(id = "", userId = currentUserId))
                    count++
                }
            }
            _statusBanner.value = if (count > 0) "Installed $count starter skills." else "All starter skills already installed."
        }
    }

    fun toggleSkillEnabled(skill: AiSkill) {
        viewModelScope.launch {
            cloudRepository.toggleSkillEnabled(currentUserId, skill.id, !skill.enabled)
        }
    }

    fun deleteSkill(skillId: String) {
        viewModelScope.launch {
            if (_selectedSkillId.value == skillId) _selectedSkillId.value = null
            cloudRepository.deleteSkill(currentUserId, skillId)
        }
    }

    fun togglePlugin(pluginId: String) {
        val current = (settingsState.value as? UiState.Success)?.data
            ?: UserSettings(userId = currentUserId, displayName = initialDisplayName)
        val updatedList = if (pluginId in current.enabledPluginIds) {
            current.enabledPluginIds - pluginId
        } else {
            current.enabledPluginIds + pluginId
        }
        saveSettings(current.copy(enabledPluginIds = updatedList))
    }

    fun runPluginSandbox(pluginId: String, input: String) {
        viewModelScope.launch {
            _sandboxResult.value = pluginEngine.runSandboxInput(pluginId, input, currentUserId)
        }
    }

    fun clearSandboxResult() {
        _sandboxResult.value = null
    }

    fun addMemory(title: String, content: String, tag: String) {
        viewModelScope.launch {
            cloudRepository.addMemory(currentUserId, title, content, tag)
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            cloudRepository.deleteMemory(currentUserId, memoryId)
        }
    }

    fun saveSettings(updated: UserSettings) {
        viewModelScope.launch {
            val res = cloudRepository.updateSettings(currentUserId, updated)
            if (res.isFailure) {
                _statusBanner.value = "Failed to sync settings: ${res.exceptionOrNull()?.message}"
            }
        }
    }
}
