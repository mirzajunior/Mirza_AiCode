const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validSettingsPayload(uid, now) {
  return {
    userId: uid,
    displayName: "Mirza",
    preferredModelId: "anthropic/claude-3.7-sonnet",
    customInstructions: "Analyze complex data concisely.",
    themeMode: "SYSTEM",
    responseLanguage: "ID",
    temperature: 0.4,
    maxTokens: 4096,
    streamingEnabled: true,
    showReasoning: true,
    enabledPluginIds: ["data_analyzer", "calculator", "web_fetcher"],
    createdAt: now,
    updatedAt: now,
  };
}

function validConversationPayload(uid, now) {
  return {
    userId: uid,
    title: "Q4 Revenue Analysis",
    modelId: "anthropic/claude-3.7-sonnet",
    activeSkillId: "skill_data",
    lastMessagePreview: "Analyzing quarterly growth...",
    pinned: false,
    messageCount: 1,
    createdAt: now,
    updatedAt: now,
  };
}

function validMessagePayload(uid, now) {
  return {
    userId: uid,
    role: "assistant",
    content: "Mean revenue is $125,000 with +14.2% MoM growth.",
    reasoning: "Parsed 12 CSV rows and ran descriptive stats.",
    modelId: "anthropic/claude-3.7-sonnet",
    skillName: "Data Scientist",
    attachmentSummary: "q4_revenue.csv (12 rows)",
    pluginLog: "[data_analyzer] rows=12, cols=4",
    createdAt: now,
    updatedAt: now,
  };
}

function validSkillPayload(uid, now) {
  return {
    userId: uid,
    name: "Deep Data Analyst",
    slashCommand: "/analyze",
    category: "DATA",
    description: "Performs statistical profiling and anomaly detection.",
    systemPrompt: "You are a senior quantitative data analyst.",
    preferredModelId: "anthropic/claude-3.7-sonnet",
    temperature: 0.2,
    workflowSteps: ["Profile dataset schema", "Compute metrics & outliers", "Summarize insights"],
    attachedPluginIds: ["data_analyzer", "calculator"],
    enabled: true,
    createdAt: now,
    updatedAt: now,
  };
}

function validMemoryPayload(uid, now) {
  return {
    userId: uid,
    title: "KPI Target 2026",
    content: "Target gross margin >= 42%.",
    tag: "finance",
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) await testEnv.cleanup();
});

beforeEach(async () => {
  if (testEnv) await testEnv.clearFirestore();
});

test("Unauthenticated access is rejected across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 1000);

  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).set(validSettingsPayload(ALICE_UID, now)));
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("conversations").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("skills").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("memories").get());
});

test("UserSettings: owner create/update succeeds; cross-user, ghost field, and future timestamp fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validSettingsPayload(ALICE_UID, created))
  );

  // Partial update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredModelId: "deepseek/deepseek-r1",
      temperature: 0.6,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Cross-user read & write rejected
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hacked", updatedAt: new Date(Date.now() - 500) }));

  // Shadow/ghost field rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Immutable createdAt mutation rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Future timestamp rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "Future",
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Conversations and Messages: create, list, update, and parent-gate check", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 5000);

  // Empty list query succeeds for owner
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("conversations").get());
  // Cross-user list fails
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("conversations").get());

  // Orphaned message without parent conversation must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID)
      .collection("conversations").doc("conv_missing")
      .collection("messages").doc("msg_1")
      .set(validMessagePayload(ALICE_UID, created))
  );

  // Create conversation + message
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID)
      .collection("conversations").doc("conv_1")
      .set(validConversationPayload(ALICE_UID, created))
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID)
      .collection("conversations").doc("conv_1")
      .collection("messages").doc("msg_1")
      .set(validMessagePayload(ALICE_UID, created))
  );

  // Reject unexpected @DocumentId 'id' field in payload
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID)
      .collection("conversations").doc("conv_2")
      .set({ ...validConversationPayload(ALICE_UID, created), id: "conv_2" })
  );

  // Update conversation metadata
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID)
      .collection("conversations").doc("conv_1")
      .update({
        pinned: true,
        messageCount: 2,
        lastMessagePreview: "Updated preview",
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Reject message role mutation on update
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID)
      .collection("conversations").doc("conv_1")
      .collection("messages").doc("msg_1")
      .update({
        role: "user",
        updatedAt: new Date(Date.now() - 500),
      })
  );
});

test("Skills and Memories: owner CRUD succeeds; invalid category or cross-user fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("skills").doc("skill_1")
      .set(validSkillPayload(ALICE_UID, created))
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("skills").doc("skill_1")
      .update({
        enabled: false,
        workflowSteps: ["Step 1", "Step 2"],
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Invalid category rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("skills").doc("skill_bad")
      .set({ ...validSkillPayload(ALICE_UID, created), category: "INVALID_CAT" })
  );

  // Cross-user skill access rejected
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("skills").doc("skill_1").get());

  // Workspace memories CRUD
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1")
      .set(validMemoryPayload(ALICE_UID, created))
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1")
      .update({ content: "Updated KPI >= 45%", updatedAt: new Date(Date.now() - 1000) })
  );
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1").delete());
});
